<?php
include './db_connection.php'; // database connection 

session_start();

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    // Redirect to login page or display an error message
    header("Location: ../"); // Adjust the redirection URL as needed
    exit(); // Stop further execution of the script
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Extract form data
    $about = $_POST['about'];
    $company = $_POST['company'];
    $job = $_POST['job'];
    $country = $_POST['country'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    $twitter = $_POST['twitter'];
    $facebook = $_POST['facebook'];
    $instagram = $_POST['instagram'];
    $linkedin = $_POST['linkedin'];
    $username = $_SESSION['username']; // Get username from session

    // Update the database
    $sql = "UPDATE users SET about = ?, company = ?, job = ?, country = ?, address = ?, phone = ?, twitter = ?, facebook = ?, instagram = ?, linkedin = ? WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssssss", $about, $company, $job, $country, $address, $phone, $twitter, $facebook, $instagram, $linkedin, $username);

    if ($stmt->execute()) {
        // Redirect to the same URL after successful update
        msg('success', 'Profile data successfully updated');
        header("refresh: 1; url=../user/users-profile.php");
        exit();
    } else {
        // echo "Error updating record: " . $conn->error;
        msg('danger', 'Profile data not updated!');
        header("refresh: 1; url=../user/users-profile.php");
    }
}

// Close connection
$stmt->close();
$conn->close();
?>
