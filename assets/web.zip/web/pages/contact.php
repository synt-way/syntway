<main id="contact" class="container-fluid py-2">

  <h1 class="web-title text-center pb-4">Contact Us</h1>

  <div class="row">
  
    <!-- Contact Information -->
    <div class="col-lg-6">
      <div class="row">

        <div class="col-md-6">
          <div class="info-box card" data-aos="fade-up-left">
            <i class="bi bi-geo-alt"></i>
            <h3>Address</h3>
            <p>Khaga Fatehpur<br>Uttar pradesh IN-212655</p>
          </div>
        </div>

        <div class="col-md-6">
          <div class="info-box card" data-aos="fade-up-right">
            <i class="bi bi-telephone"></i>
            <h3>Call Us</h3>
            <p>
              <a href="tel:+918948263861">+91 89482 63861</a><br>
              <a href="tel:+917310089887">+91 73100 89887</a>  
            </p>
          </div>
        </div>

        <div class="col-md-6">
          <div class="info-box card" data-aos="fade-down-left">
            <i class="bi bi-envelope"></i>
            <h3>Email Us</h3>
            <p>
              <a href="mailto:synt.way@gmail.com">synt.way@gmail.com</a><br>
              <a href="mailto:synt.way@syntway.org">synt.way@syntway.org</a>
            </p>
          </div>
        </div>

        <div class="col-md-6">
          <div class="info-box card" data-aos="fade-down-right">
            <i class="bi bi-clock"></i>
            <h3>Open Hours</h3>
            <p>Monday - Saturday<br>9:00AM - 05:00PM</p>
          </div>
        </div>

      </div>
    </div>
    <!-- End Contact Information -->

    <!-- Contact Form -->
    <div class="col-lg-6">
        <div class="card p-4" data-aos="zoom-in">
        <form class="needs-validation php-email-form" novalidate action="" method="post" id="emailForm">
            <div class="row">
                <div class="col-md-6 form-group input">
                    <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required>
                    <div class="invalid-feedback">Please enter your First name.</div>
                </div>

                <div class="col-md-6 form-group mt-3 mt-md-0">
                    <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required>
                    <div class="invalid-feedback">Please enter your email address.</div>
                </div>
            </div>

            <div class="form-group mt-3">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" required>
                <div class="invalid-feedback">Please enter your subject.</div>
            </div>

            <div class="form-group mt-3">
                <textarea class="form-control" name="message" rows="6" placeholder="Message" required></textarea>
                <div class="invalid-feedback">Please enter your message.</div>
            </div>
            <!-- loading spinner -->
            <div class="my-3 d-flex justify-content-center">
                <div class="spinner-border text-primary d-none align-self-center" role="status" id="loadingSpinner">
                    <span class="sr-only"></span>
                </div>
            </div>
            <!-- alert message -->
            <div class="my-3">
                <div class="alert alert-success d-none" role="alert" id="successMessage"></div>
                <div class="alert alert-danger d-none" role="alert" id="errorMessage"></div>
            </div>

            <div class="text-center mt-3">
                <button type="submit" class="btn btn-primary">Send Message</button>
            </div>
          </form>
        </div>
    </div><!-- End Contact Form -->

  </div>

</main><!-- End #main -->
