<?php 
include './db_connection.php'; // database connection 

session_start();

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    // Redirect to login page or display an error message
    header("Location: ../"); // Adjust the redirection URL as needed
    exit(); // Stop further execution of the script
}

// Fetch user information
$username = $_SESSION['username'];

// Check if the delete form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["confirm_delete"])) {
    // Delete user data from the database
    $sql = "DELETE FROM users WHERE `users`.`username` = '$username';";
    if ($conn->query($sql) === TRUE) {
        msg('success', 'Your account successfully deleted');
        session_unset();
        session_destroy();
        header('refresh: 1; url=../');
        exit();
    } else {
        // Handle delete error
        msg('danger', 'Its server error. Please try again later'); 
        header('refresh: 1; url=../user/users-profile.php'); 
    }
}
alert('Delete Account', 'Are you sure you want to permanently delete your account? This action cannot be undone.', 'confirm_delete', 'Delete', 'text-danger'); 
$conn->close();
?>