// import './index/' folder to all files 
import * as index from './index/index.js';
