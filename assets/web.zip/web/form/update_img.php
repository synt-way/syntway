<?php
include './db_connection.php'; // database connection 

session_start();

   // Check if user is logged in
   if (!isset($_SESSION['username'])) {
       // Redirect to login page or display an error message
       header("Location: ../"); // Adjust the redirection URL as needed
       exit(); // Stop further execution of the script
   }
   

   // Fetch user information
   $username = $_SESSION['username'];

    if(isset($_POST["submit"])) {
        $image_name = $_FILES['fileToUpload']['name'];
        $image_tmp = $_FILES['fileToUpload']['tmp_name'];
        $image_type = $_FILES['fileToUpload']['type'];

        // Check if file is an image
        $allowed_types = array('image/jpeg', 'image/png', 'image/jpg');
        if (!in_array($image_type, $allowed_types)) {
            msg('danger', 'Only .jpg, .jpeg, .png and file size < 960px.');
            die(header('refresh: 1; url= ../user/users-profile.php'));
        }

        // Read the image file
        $image_data = file_get_contents($image_tmp);

        // Escape special characters in the image data
        $escaped_image_data = $conn->real_escape_string($image_data);

        // Update image data into the database
        $sql = "UPDATE `users` SET `image_name`='$image_name',`image_data`='$escaped_image_data' WHERE `username` = '$username'";
        
        if ($conn->query($sql) === TRUE) {
            // Redirect to profile.php after successful upload
            msg('success', 'Profile picture successfully uploaded.');
            header("refresh: 1; url=../user/users-profile.php");
            exit();
        } else {
            msg('danger', 'Only .jpg, .jpeg, .png and file size < 960px.');
            header("refresh: 1; url=../user/users-profile.php");
            // echo 'Error: ' . $sql . '<br>' . $conn->error ; 
        }
    } else {
        msg('danger', 'Only .jpg, .jpeg, .png and file size < 960px.');
        header("refresh: 1; url=../user/users-profile.php");
        // echo 'Error: ' . $sql . '<br>' . $conn->error ; 
    }
?>
