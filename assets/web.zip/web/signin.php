<?php 
   include './inc/header.php'; // include header section 
   include './pages/signin.php'; // signup section 
   include './inc/footer.php'; // include footer section 
?>