<?php
session_start();

// Include PHPMailer classes
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require './contact-form/PHPMailer/src/Exception.php';
require './contact-form/PHPMailer/src/PHPMailer.php';
require './contact-form/PHPMailer/src/SMTP.php';

// Include database connection
require './db_connection.php';

// Initialize PHPMailer
$mail = new PHPMailer(true);

// Define variable to store error and success message
$error_message = '';


// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['submit_username'])) {
        $username = $_POST['username'];

        // Validate email format
        if (!filter_var($username, FILTER_VALIDATE_EMAIL)) {
            $error_message = 'Invalid email format.';
        } else {
            // Check if username exists in the database
            $sql = "SELECT * FROM users WHERE username = '$username'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // User exists, send email with code
                $reset_code = mt_rand(100000, 999999); // Generate 6-digit code

                // Store reset code in session
                $_SESSION['reset_code'] = $reset_code;

                // SMTP configuration
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->Port = 587;
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->SMTPAuth = true;
                $mail->Username = 'synt.way@gmail.com';
                $mail->Password = 'ostj hgkh tiwg kulb'; // Replace with your SMTP password

                // Sender and recipient
                $mail->setFrom('synt.way@gmail.com', 'Syntway');
                $mail->addAddress($username);

                // Email content
                $mail->isHTML(true);
                $mail->Subject = 'Password Reset Code';
                $mail->Body = 'Your password reset code is: ' . $reset_code;

                try {
                    // Send the email
                    $mail->send();

                    // Redirect to the verification code form
                    header("Location: {$_SERVER['PHP_SELF']}?username=$username&action=enter_code");
                    exit();
                } catch (Exception $e) {
                    $error_message = 'Failed to send email. Error: ' . $mail->ErrorInfo;
                }
            } else {
                // User does not exist
                $error_message = 'User does not exist.';
            }
        }
    } elseif (isset($_POST['submit_code'])) {
        // Retrieve username and code from the form
        $username = $_POST['username'];
        $code = $_POST['code'];

        // Check if the entered code matches the one sent via email
        // Retrieve the stored code from the session
        $stored_code = isset($_SESSION['reset_code']) ? $_SESSION['reset_code'] : '';

        if ($code == $stored_code) {
            // Code is valid, proceed to password creation form
            header("Location: {$_SERVER['PHP_SELF']}?username=$username&action=create_password");
            exit();
        } else {
            // Invalid code, set error message and display verification code form
            $error_message = 'Invalid verification code';
            header("Location: {$_SERVER['PHP_SELF']}?username=$username&action=enter_code");
            exit();
        }
        
         
    } elseif (isset($_POST['submit_password'])) {
        // Extract form data
        $newPassword = $_POST['newPassword'];
        $repeatPassword = $_POST['repeatPassword'];
        $username = $_POST['username']; // Get username from session
        
        // Check if passwords match
        if ($repeatPassword === $newPassword) {
            // Prepare and bind parameters to prevent SQL injection
            $stmt = $conn->prepare("UPDATE users SET password = ? WHERE username = ?");
            $stmt->bind_param("ss", $newPassword, $username);

            // Execute the statement
            if ($stmt->execute()) {
                // Password successfully updated
                // Redirect to profile page or display a success message
                $success_message = 'Your password successfully created'; 
                header("Location: ../signin.php");
                exit();
            } else {
                // Error updating password
                $error_message = 'Failed to update password. Please try again.';
                header("Location: {$_SERVER['PHP_SELF']}?username=$username&action=create_password");
                exit();
            }
        } else {
            // Passwords do not match
            $error_message = 'Passwords do not match.';
            header("Location: {$_SERVER['PHP_SELF']}?username=$username&action=create_password");
            exit();
        }

    }      

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Syntway</title>
    <link rel="shortcut icon" href="../assets/img/logo.png" type="image/x-icon">
    <link rel="apple-touch-icon" href="../assets/img/logo.png">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../assets/node_modules/bootstrap/dist/css/bootstrap.min.css">
    <style>
        @font-face {
            font-family: 'DM Sans';
            src: url('../assets/node_modules/DM_Sans/DMSans-VariableFont_opsz,wght.ttf') format('truetype');
        }

        body {
            font-family: 'DM Sans';
        }

        .card {
            box-shadow: 0px 0px 12px 0px rgba(0, 0, 0, 0.15);
            border: 0;
        }

        .title {
            font-size: 18px;
            font-weight: 400;
            color: #012970;
        }
    </style>
</head>
<body>
<!-- sign in section -->
<section class="vh-100 d-flex align-items-center justify-content-center">
  <div class="container text-center">
    <div class="row justify-content-center">
      <div class="col-lg-4 col-md-6">
        <div class="card">
            <div class="card-header"><h1 class="title m-0">Syntway</h1></div>
            <div class="card-body">
                <!-- show backend errors -->
                <?php if (!empty($error_message)) : ?>
                    <div class="alert alert-danger p-2"><?php echo $error_message; ?></div>
                <?php endif; ?>

                <?php if (!empty($_GET['username']) && isset($_GET['action']) && $_GET['action'] === 'create_password') : ?>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" class="needs-validation" onsubmit="return validateForm()" novalidate>
                        <input type="hidden" name="username" value="<?php echo htmlspecialchars($_GET['username']); ?>">
                        <div class="form-group mb-3">
                            <label for="newPassword" class="form-label">New Password</label>
                            <input type="password" id="newPassword" name="newPassword" class="form-control" required>
                            <div id="newPasswordError" class="text-danger small"></div>
                        </div>
                        <div class="form-group mb-3">
                            <label for="repeatPassword" class="form-label">Repeat Password</label>
                            <input type="password" id="repeatPassword" name="repeatPassword" class="form-control" required>
                            <div id="repeatPasswordError" class="text-danger small"></div>
                        </div>
                        <button type="submit" name="submit_password" class="btn btn-primary w-100">Create</button>
                    </form>

                <?php elseif (!empty($_GET['username']) && isset($_GET['action']) && $_GET['action'] === 'enter_code') : ?>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" class="needs-validation" onsubmit="return validateCode()" novalidate>
                        <input type="hidden" name="username" value="<?php echo htmlspecialchars($_GET['username']); ?>">
                        <div class="form-group mb-3">
                            <label for="code" class="form-label">Enter Verification Code:</label>
                            <input type="text" id="code" name="code" class="form-control" required>
                            <div class="invalid-feedback">Verification code do not empty!</div>
                        </div>
                        <button type="submit" name="submit_code" class="btn btn-primary w-100">Submit</button>
                    </form>
                    
                <?php else : ?>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" class="needs-validation" novalidate>
                        <div class="form-group mb-3">
                            <label for="username" class="form-label">Enter your email address</label>
                            <input type="email" id="username" name="username" class="form-control" required>
                            <div class="invalid-feedback">Please enter a valid email address.</div>
                        </div>
                        <button type="submit" name="submit_username" class="btn btn-primary w-100">Submit</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>

      </div>
    </div>
  </div>

</section>

<!-- Bootstrap JS (optional) -->
<script src="../assets/node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Bootstrap validation script
    (function () {
        'use strict';
        var forms = document.querySelectorAll('.needs-validation');
        Array.prototype.slice.call(forms)
            .forEach(function (form) {
                form.addEventListener('submit', function (event) {
                    if (!form.checkValidity()) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                }, false);
            });
    })();

    // password creation script 
    function validateForm() {
        var newPassword = document.getElementById('newPassword').value;
        var repeatPassword = document.getElementById('repeatPassword').value;
        var newPasswordError = document.getElementById('newPasswordError');
        var repeatPasswordError = document.getElementById('repeatPasswordError');

        newPasswordError.textContent = '';
        repeatPasswordError.textContent = '';

        if (newPassword.trim() === '') {
            newPasswordError.textContent = 'New Password cannot be empty.';
            return false;
        }

        if (repeatPassword.trim() === '') {
            repeatPasswordError.textContent = 'Repeat Password cannot be empty.';
            return false;
        }

        if (newPassword !== repeatPassword) {
            repeatPasswordError.textContent = 'Passwords do not match.';
            return false;
        }

        // Custom validation
        var passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*]).{8,}$/;
        if (!passwordRegex.test(newPassword)) {
            newPasswordError.textContent = 'Requires a lowercase, uppercase, number, special character and 8+ characters.';
            return false;
        }

        return true; 
    }
</script>   
</body>
</html>


