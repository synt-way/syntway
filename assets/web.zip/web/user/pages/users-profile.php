
  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Profile</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">Users</li>
          <li class="breadcrumb-item active">Profile</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section profile">
      <div class="row">
        <div class="col-xl-4">

        <div class="card">
            <div class="card-body profile-card pt-4 d-flex flex-column align-items-center">

              <img src="<?php echo $src ?>" alt="Profile" class="rounded-circle">
              <h2><?php echo $fullname; ?></h2>
              <h3><?php echo $job; ?></h3>
              <p class="small fst-italic text-center"><?php echo $about; ?></p>
              
              <div class="social-links mt-2">
                <a href="<?php echo $twitter; ?>" class="twitter"><i class="bi bi-twitter"></i></a>
                <a href="<?php echo $facebook; ?>" class="facebook"><i class="bi bi-facebook"></i></a>
                <a href="<?php echo $instagram; ?>" class="instagram"><i class="bi bi-instagram"></i></a>
                <a href="<?php echo $linkedin; ?>" class="linkedin"><i class="bi bi-linkedin"></i></a>
              </div>

            </div>
          </div>

        </div>

        <div class="col-xl-8">

        <div class="card">
            <div class="card-body pt-3">
              <!-- Bordered Tabs -->
              <ul class="nav nav-tabs nav-tabs-bordered">

                <li class="nav-item">
                  <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#profile-overview">Overview</button>
                </li>

                <li class="nav-item">
                  <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-edit">Edit Profile</button>
                </li>

                <li class="nav-item">
                  <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-settings">Settings</button>
                </li>

                <li class="nav-item">
                  <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-change-password">Change Password</button>
                </li>

              </ul>
              <div class="tab-content pt-2">

                <div class="tab-pane fade show active profile-overview" id="profile-overview">
                  <h5 class="card-title">About</h5>
                  <p class=""><?php echo $about; ?></p>

                  <h5 class="card-title">Profile Details</h5>

                  <div class="row">
                      <div class="col-lg-3 col-md-4 label">Full Name</div>
                      <div class="col-lg-9 col-md-8"><?php echo $fullname; ?></div>
                  </div>

                  <div class="row">
                      <div class="col-lg-3 col-md-4 label">Company</div>
                      <div class="col-lg-9 col-md-8"><?php echo $company; ?></div>
                  </div>

                  <div class="row">
                      <div class="col-lg-3 col-md-4 label">Job</div>
                      <div class="col-lg-9 col-md-8"><?php echo $job; ?></div>
                  </div>

                  <div class="row">
                      <div class="col-lg-3 col-md-4 label">Country</div>
                      <div class="col-lg-9 col-md-8"><?php echo $country; ?></div>
                  </div>

                  <div class="row">
                      <div class="col-lg-3 col-md-4 label">Address</div>
                      <div class="col-lg-9 col-md-8"><?php echo $address; ?></div>
                  </div>

                  <div class="row">
                      <div class="col-lg-3 col-md-4 label">Phone</div>
                      <div class="col-lg-9 col-md-8"><?php echo $phone; ?></div>
                  </div>

                  <div class="row">
                      <div class="col-lg-3 col-md-4 label">Username</div>
                      <div class="col-lg-9 col-md-8"><?php echo $username; ?></div>
                  </div>

                </div>

                <!-- Profile Edit Form -->
                <div class="tab-pane fade profile-edit pt-3" id="profile-edit">

                <form action="../form/update_img.php" method="post" enctype="multipart/form-data">
                    <div class="row mb-3">
                        <label for="fileToUpload" class="col-md-4 col-lg-3 col-form-label">Profile Image</label>
                        <div class="col-md-8 col-lg-9">
                            <div class="d-flex">
                              <button type="submit" class="btn btn-outline-primary" name="submit"><i class='bi bi-upload'></i></button>
                              <input type="file" class="form-control ms-2" id="fileToUpload" name="fileToUpload">
                            </div>
                            <!-- <div class="pt-2">
                                <button type="submit" class="btn btn-primary" name="submit"><i class='bi bi-upload'></i></button>
                                <button type="reset" class="btn btn-danger btn-sm"><i class='bi bi-trash'></i></button>
                            </div> -->
                            <!-- <p class="small fst-italic text-success mt-2 mb-0 ms-5">Sqare images and max file size 960kb.</p> -->
                        </div>
                    </div>
                </form>



                  <!-- update profile info form -->
                  <form method="post" action="../form/update_profile.php">
                    <div class="row mb-3">
                      <label for="fullName" class="col-md-4 col-lg-3 col-form-label">Full Name</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="fullName" type="text" class="form-control" id="fullName" value="<?php echo $fullname; ?>" disabled>
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="about" class="col-md-4 col-lg-3 col-form-label">About</label>
                      <div class="col-md-8 col-lg-9">
                        <textarea name="about" class="form-control" id="about" style="height: 100px" maxlength="255"><?php echo $about; ?></textarea>
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="company" class="col-md-4 col-lg-3 col-form-label">Company</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="company" type="text" class="form-control" id="company" value="<?php echo $company; ?>">
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="Job" class="col-md-4 col-lg-3 col-form-label">Job</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="job" type="text" class="form-control" id="Job" value="<?php echo $job; ?>">
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="Country" class="col-md-4 col-lg-3 col-form-label">Country</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="country" type="text" class="form-control" id="Country" value="<?php echo $country; ?>">
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="Address" class="col-md-4 col-lg-3 col-form-label">Address</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="address" type="text" class="form-control" id="Address" value="<?php echo $address; ?>">
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="Phone" class="col-md-4 col-lg-3 col-form-label">Phone</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="phone" type="text" class="form-control" id="Phone" value="<?php echo $phone; ?>">
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="username" class="col-md-4 col-lg-3 col-form-label">Username</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="username" type="email" class="form-control" id="username" value="<?php echo $username; ?>" disabled>
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="Twitter" class="col-md-4 col-lg-3 col-form-label">Twitter Profile</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="twitter" type="text" class="form-control" id="Twitter" value="<?php echo $twitter; ?>">
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="Facebook" class="col-md-4 col-lg-3 col-form-label">Facebook Profile</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="facebook" type="text" class="form-control" id="Facebook" value="<?php echo $facebook; ?>">
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="Instagram" class="col-md-4 col-lg-3 col-form-label">Instagram Profile</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="instagram" type="text" class="form-control" id="Instagram" value="<?php echo $instagram; ?>">
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="Linkedin" class="col-md-4 col-lg-3 col-form-label">Linkedin Profile</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="linkedin" type="text" class="form-control" id="Linkedin" value="<?php echo $linkedin; ?>">
                      </div>
                    </div>

                    <div class="text-center">
                      <button type="submit" class="btn btn-primary">Save Changes</button>
                    </div>
                  </form><!-- End Profile Edit Form -->

                </div>

                <div class="tab-pane fade pt-3" id="profile-settings">

                  <!-- Settings Form -->
                  <!-- <form>

                    <div class="row mb-3">
                      <label for="fullName" class="col-md-4 col-lg-3 col-form-label">Email Notifications</label>
                      <div class="col-md-8 col-lg-9">
                        <div class="form-check">
                          <input class="form-check-input" type="checkbox" id="changesMade" checked>
                          <label class="form-check-label" for="changesMade">
                            Changes made to your account
                          </label>
                        </div>
                        <div class="form-check">
                          <input class="form-check-input" type="checkbox" id="newProducts" checked>
                          <label class="form-check-label" for="newProducts">
                            Information on new products and services
                          </label>
                        </div>
                        <div class="form-check">
                          <input class="form-check-input" type="checkbox" id="proOffers">
                          <label class="form-check-label" for="proOffers">
                            Marketing and promo offers
                          </label>
                        </div>
                        <div class="form-check">
                          <input class="form-check-input" type="checkbox" id="securityNotify" checked disabled>
                          <label class="form-check-label" for="securityNotify">
                            Security alerts
                          </label>
                        </div>
                      </div>
                    </div>

                    <div class="text-center">
                      <button type="submit" class="btn btn-primary">Save Changes</button>
                    </div>
                  </form> -->
                  <!-- End settings Form -->

                  <!-- Danger jone -->
                  <p class="text-danger">Do you want to delete your account ?</p>
                  <a href="../form/delete.php" class="btn btn-danger">Delete</a>

                </div>

                <div class="tab-pane fade pt-3" id="profile-change-password">
                  <!-- Change Password Form -->
                  <form action="../form/password_update.php" method="post" id="resetForm" onsubmit="return validateForm()">

                    <div class="row mb-3">
                      <label for="password" class="col-md-4 col-lg-3 col-form-label">Current Password</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="password" type="password" class="form-control" id="currentPassword" value="<?php echo $password; ?>" disabled>
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="newpassword" class="col-md-4 col-lg-3 col-form-label">New Password</label>
                      <div class="col-md-8 col-lg-9">
                        <input type="text" class="form-control" id="newPassword" name="newpassword">
                        <div id="newPasswordError" class="text-danger small"></div>
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="repeatpassword" class="col-md-4 col-lg-3 col-form-label">Repeat Password</label>
                      <div class="col-md-8 col-lg-9">
                        <input type="text" class="form-control" id="repeatPassword" name="repeatpassword">
                        <div id="repeatPasswordError" class="text-danger small"></div>
                      </div>
                    </div>

                    <div class="text-center">
                      <button type="submit" class="btn btn-primary">Change Password</button>
                    </div>
                  </form><!-- End Change Password Form -->

                </div>

              </div><!-- End Bordered Tabs -->

            </div>
          </div>

        </div>
      </div>
    </section>

  </main><!-- End #main -->

<!-- update password handling script -->
<script>
  function validateForm() {
    var newPassword = document.getElementById('newPassword').value;
    var repeatPassword = document.getElementById('repeatPassword').value;
    var newPasswordError = document.getElementById('newPasswordError');
    var repeatPasswordError = document.getElementById('repeatPasswordError');

    newPasswordError.textContent = '';
    repeatPasswordError.textContent = '';

    if (newPassword.trim() === '') {
      newPasswordError.textContent = 'New Password cannot be empty.';
      return false;
    }

    if (repeatPassword.trim() === '') {
      repeatPasswordError.textContent = 'Repeat Password cannot be empty.';
      return false;
    }

    if (newPassword !== repeatPassword) {
      repeatPasswordError.textContent = 'Please enter a same password.';
      return false;
    }

    // Custom validation
    var passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*]).{8,}$/;
    if (!passwordRegex.test(newPassword)) {
      newPasswordError.textContent = 'Requires a lowercase, uppercase, number, special character and 8+ characters.';
      return false;
    }

    return true; 
  }
</script>
