    <!-- ======= Team Section ======= -->
    <section id="team" class="team pt-2 pb-4">
      <div class="container-fluid">

        <div class="text-center" data-aos="fade-down">
          <h1 class="web-title">Team</h1>
          <p data-aos="zoom-in" class="container">Lorem ipsum dolor sit amet consectetur adipisicing elit. Illo, vero. Tenetur corporis commodi earum assumenda. Beatae soluta delectus numquam sapiente nesciunt. Saepe, eos possimus. Doloremque, suscipit eos! Expedita, placeat esse.</p>
        </div>
        <div class="row">
          
          <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-left" data-aos-duration="2000">
            <div class="member">
              <img src="assets/img/team/cute.jpg" alt="" data-aos="zoom-in" data-aos-duration="2000">
              <div data-aos="fade-down">
                <h4>Walter White</h4>
                <span>Chief Executive Officer</span>
              </div>
              <p data-aos="zoom-in">
                Magni qui quod omnis unde et eos fuga et exercitationem. Odio veritatis perspiciatis quaerat qui aut aut aut
              </p>
              <div class="social" data-aos="fade-up">
                <a href=""><i class="bi bi-twitter"></i></a>
                <a href=""><i class="bi bi-facebook"></i></a>
                <a href=""><i class="bi bi-instagram"></i></a>
                <a href=""><i class="bi bi-linkedin"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-right" data-aos-duration="2000">
            <div class="member">
              <img src="assets/img/team/cute.jpg" alt="" data-aos="zoom-in" data-aos-duration="2000">
              <div data-aos="fade-down">
                <h4>Sarah Jhinson</h4>
                <span>Product Manager</span>
              </div>
              <p data-aos="zoom-in">
                Repellat fugiat adipisci nemo illum nesciunt voluptas repellendus. In architecto rerum rerum temporibus
              </p>
              <div class="social" data-aos="fade-up">
                <a href=""><i class="bi bi-twitter"></i></a>
                <a href=""><i class="bi bi-facebook"></i></a>
                <a href=""><i class="bi bi-instagram"></i></a>
                <a href=""><i class="bi bi-linkedin"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-left" data-aos-duration="2000">
            <div class="member">
              <img src="assets/img/team/cute.jpg" alt="" data-aos="zoom-in" data-aos-duration="2000">
              <div data-aos="fade-down">
                <h4>Walter White</h4>
                <span>Chief Executive Officer</span>
              </div>
              <p data-aos="zoom-in">
                Magni qui quod omnis unde et eos fuga et exercitationem. Odio veritatis perspiciatis quaerat qui aut aut aut
              </p>
              <div class="social" data-aos="fade-up">
                <a href=""><i class="bi bi-twitter"></i></a>
                <a href=""><i class="bi bi-facebook"></i></a>
                <a href=""><i class="bi bi-instagram"></i></a>
                <a href=""><i class="bi bi-linkedin"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-right" data-aos-duration="2000">
            <div class="member">
              <img src="assets/img/team/cute.jpg" alt="" data-aos="zoom-in" data-aos-duration="2000">
              <div data-aos="fade-down">
                <h4>Sarah Jhinson</h4>
                <span>Product Manager</span>
              </div>
              <p data-aos="zoom-in">
                Repellat fugiat adipisci nemo illum nesciunt voluptas repellendus. In architecto rerum rerum temporibus
              </p>
              <div class="social" data-aos="fade-up">
                <a href=""><i class="bi bi-twitter"></i></a>
                <a href=""><i class="bi bi-facebook"></i></a>
                <a href=""><i class="bi bi-instagram"></i></a>
                <a href=""><i class="bi bi-linkedin"></i></a>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Team Section -->

    