<?php 
  include './form/mail.php'; // contact form handling 
  include './inc/header.php'; 
  include './pages/header.php';
  include './pages/hero.php'; 
  include './pages/main.php'; 
  include './pages/footer.php'; 
  include './inc/footer.php'; 
?>