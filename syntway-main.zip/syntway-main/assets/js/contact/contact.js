// import faq.js file from ./module/
import * as faq from './module/faq.js';
// import contact.js file home/module/
import * as contact from '../home/module/contact.js';
