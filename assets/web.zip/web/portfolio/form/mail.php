<?php
    // Include PHPMailer classes
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

    require '../form/contact-form/PHPMailer/src/Exception.php';
    require '../form/contact-form/PHPMailer/src/PHPMailer.php';
    require '../form/contact-form/PHPMailer/src/SMTP.php';

    // Initialize error and success messages
    $error_message = '';
    $sent_message = '';

    // Check if the form is submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Create a new PHPMailer instance
        $mail = new PHPMailer(true);

        try {
            // SMTP configuration
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com'; // Gmail SMTP server
            $mail->Port = 587; // TLS/STARTTLS port
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Enable TLS encryption
            $mail->SMTPAuth = true; // Enable SMTP authentication
            $mail->Username = 'synt.way@gmail.com'; // Your Gmail username
            $mail->Password = 'ostj hgkh tiwg kulb'; // Your Gmail password or app-specific password

            // Sender and recipient
            $mail->setFrom($_POST['email'], $_POST['name']); // Set sender's email and name
            $mail->addAddress('synt.way@gmail.com', ''); // Set recipient's email

            // Email content
            $mail->isHTML(true); // Set email format to HTML
            $mail->Subject = $_POST['subject']; // Set email subject
            $mail->Body = $_POST['message']; // Set email body

            // Send the email
            $mail->send();
            $sent_message = 'Your message has been sent. Thank you!';
            
            // Return JSON response
            echo json_encode(array('success' => true, 'message' => $sent_message));
            exit;
        } catch (Exception $e) {
            $error_message = 'Message could not be sent. Error: ' . $mail->ErrorInfo;
            
            // Return JSON response
            echo json_encode(array('success' => false, 'message' => $error_message));
            exit;
        }
    }
?>
