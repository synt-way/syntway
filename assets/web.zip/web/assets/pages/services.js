// services function 
export default function services() {
   // do something 
}
services();
// End services function 