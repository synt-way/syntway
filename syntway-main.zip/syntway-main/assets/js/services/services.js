// import services.js file home/module/
import * as services from '../home/module/services.js';
// import education.js file ./module/
import * as education from './module/education.js';
// import redirect.js file ./module/
import * as redirect from './module/redirect.js';
// import webdesign.js file ./module/
import * as webdesign from './module/webdesign.js';
