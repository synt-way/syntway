<div class="container-fluid py-3">
   <h1 class="web-title">Privacy Policy</h1>
   <div class="body-text">
      <h5 class="section-title">Introduction</h5>
      <p>Welcome to Syntway's Privacy Policy. This policy outlines how we collect, use, disclose, and protect your personal information when you use our website.</p>
      
      <h5 class="section-title">Information We Collect</h5>
      <p>We may collect personal information such as your name, email address, phone number, and any other information you provide when you fill out forms on our website or interact with us through other means.</p>
      
      <h5 class="section-title">How We Use Your Information</h5>
      <p>We use the information we collect to provide, maintain, and improve our services, communicate with you, and personalize your experience. We may also use your information to send you marketing communications or promotional offers.</p>
      
      <h5 class="section-title">Sharing Your Information</h5>
      <p>We do not sell, trade, or otherwise transfer your personal information to third parties without your consent, except as required by law or as necessary to provide our services. We may share your information with trusted service providers who assist us in operating our website or conducting our business.</p>
      
      <h5 class="section-title">Security of Your Information</h5>
      <p>We take appropriate measures to protect your personal information from unauthorized access, disclosure, alteration, or destruction. However, please be aware that no method of transmission over the internet or electronic storage is 100% secure.</p>
      
      <h5 class="section-title">Your Choices</h5>
      <p>You can choose not to provide certain personal information, but it may limit your ability to use certain features of our website. You can also opt out of receiving marketing communications from us by following the unsubscribe instructions provided in the communication.</p>
      
      <h5 class="section-title">Changes to This Policy</h5>
      <p>We may update this privacy policy from time to time. Any changes will be posted on this page, and the revised policy will be effective immediately upon posting. We encourage you to review this policy periodically for any updates.</p>
      
      <h5 class="section-title">Contact Us</h5>
      <p>If you have any questions or concerns about this privacy policy or our practices regarding your personal information, please contact us at privacy@syntway.org.</p>
   </div>
</div>
