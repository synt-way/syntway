  <!-- ======= Hero Section ======= -->
  <section id="hero">
    <div class="hero-container vh-100">
      <div class="hero-logo" data-aos="fade-down" data-aos-duration="2000">
        <img class="" src="assets/img/logo.png" alt="Syntway" width="100" height="100">
      </div>
      <h1 data-aos="fade-down">Welcome to Syntway</h1>
      <h4 data-aos="zoom-in">
        Syntway is a leading software company <br>with expertise in revolutionizing educational systems <br>and delivering advanced web development <br>services.
      </h4>
      <h3 data-aos="fade-up">We create <span class="typed" data-typed-items="beautiful graphics, functional websites, working mobile apps"></span></h3>
      <div class="actions" data-aos="fade-up">
        <a href="./signin.php" data-aos="fade-left" class="btn btn-outline-primary">Sign in</a>
        <a href="./signup.php" data-aos="fade-right" class="btn btn-outline-success">Sign up</a>
      </div>
    </div>
  </section>
  <!-- End Hero -->





