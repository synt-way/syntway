// import './module/' folder to all files
// import carousel.js file
import * as carousel from './module/carousel.js';
// import about.js file
import * as about from './module/about.js';
// import whychoose.js file
import * as whychoose from './module/whychoose.js';
// import services.js file
import * as services from './module/services.js';
// import contact.js file 
import * as contact from './module/contact.js';
//independence day 
//export * as independence from './module/independence.js';
