  <!-- Vendor JS Files -->
  <script src="../assets/node_modules/purecounter/purecounter_vanilla.js"></script>
  <script src="../assets/node_modules/aos/dist/aos.js"></script>
  <script src="../assets/node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/node_modules/glightbox/dist/js/glightbox.min.js"></script>
  <script src="../assets/node_modules/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="../assets/node_modules/swiper/swiper-bundle.min.js"></script>
  <script src="../assets/node_modules/typed.js/dist/typed.umd.js"></script>
  <script src="../assets/node_modules/waypoints/noframework.waypoints.js"></script>
  <script src="../assets/node_modules/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="./assets/js/main.js"></script>