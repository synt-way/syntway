<!-- sign in section -->
<section class="vh-100 d-flex align-items-center justify-content-center">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-4 col-md-6">

        <div class="card border-0">
          <div class="card-body">
            <!-- logo section -->
            <div class="text-center">
              <h3><a href="index.html" class="brand-title fs-3">SYNTWAY</a></h3>
            </div><!-- End Logo -->

            <h5 class="web-title text-center mb-3 p-0 fw-200 fs-5">Sign in</h5>

            <form class="needs-validation" novalidate action="./form/signin.php" method="post">

              <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <div class="input-group">
                  <span class="input-group-text" id="inputGroupPrepend">@</span>
                  <input type="email" name="username" class="form-control" id="username" required style="border-radius: 0px 6px 6px 0px;" placeholder="example@gmail.com">
                  <div class="invalid-feedback">Please enter your username.</div>
                </div>
              </div>

              <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" name="password" class="form-control" id="password" required>
                <div class="invalid-feedback">Please enter your password!</div>
              </div>

              <div class="mb-3">
                <div class="d-flex justify-content-between align-items-center">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="remember" value="true" id="rememberMe">
                    <label class="form-check-label" for="rememberMe">Remember me</label>
                  </div>
                  <a href="./form/password_reset.php" class="text-primary">Forgot Password?</a>
                </div>
              </div>

              <div class="mb-3">
                <button class="btn btn-primary w-100" type="submit">Login</button>
              </div>
              <div>
                <p class="text-center mb-0 small">Don't have an account? <a href="./signup.php" class="text-primary">Sign up</a></p>
              </div>
            </form>

          </div>
        </div>

      </div>
    </div>
  </div>

</section>
