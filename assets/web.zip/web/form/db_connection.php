<?php
   include './alert.php'; // include alert() function for show confirmation
   include './msg.php'; // include msg() function for show message

   $servername = "localhost";
   $username = "root";
   $password = "";
   $dbname = "syntway";

   // Create connection
   $conn = new mysqli($servername, $username, $password, $dbname);

   // Check connection
   if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
   }
?>
