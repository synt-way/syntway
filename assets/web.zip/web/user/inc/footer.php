  <!-- Vendor JS Files -->
  <script src="../assets/node_modules/apexcharts/apexcharts.min.js"></script>
  <script src="../assets/node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/node_modules/chart.js/chart.umd.js"></script>
  <script src="../assets/node_modules/echarts/echarts.min.js"></script>
  <script src="../assets/node_modules/quill/quill.min.js"></script>
  <script src="../assets/node_modules/simple-datatables/simple-datatables.js"></script>
  <script src="../assets/node_modules/tinymce/tinymce.min.js"></script>
  <script src="../assets/node_modules/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>