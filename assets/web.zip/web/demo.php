<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Syntway</title>
    <meta name="robots" content="noindex, nofollow">
    <link rel="shortcut icon" href="http://localhost:8080/web/web/assets/img/logo.png" type="image/x-icon">
    <!-- Bootstrap CSS -->
    <link href="http://localhost:8080/web/web/assets/node_modules/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons CSS -->
    <link href="http://localhost:8080/web/web/assets/node_modules/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <!-- Custom Demo CSS -->
    <link rel="stylesheet" href="./assets/css/demo.css">
</head>

<body>
    <header id="header">
        <div class="logo">
            <a href="http:/localhost:8080/web/web/" rel="home" title="Back to Home">
               <span>Syntway</span>
            </a>
        </div>
        <div class="preview-devices">
            <ul>
                <li class="preview-test preview-devices-active" id="preview-test-desktop" title="Desktop preview of the Append template">
                    <a href="">
                        <i class="bi bi-display"></i>
                    </a>
                </li>
                <li class="preview-test" id="preview-test-tablet" title="Tablet preview of the Append template">
                    <a href="">
                        <i class="bi bi-tablet"></i>
                    </a>
                </li>
                <li class="preview-test" id="preview-test-mobile" title="Mobile preview of the Append template">
                    <a href="">
                        <i class="bi bi-phone"></i>
                    </a>
                </li>
            </ul>
        </div>

        <div class="current-template">
            <!-- Click to change to the previous template -->
            <a href="#" title="Prev Template: " class="first-latest" id="prev-template">
                <i class="bi bi-chevron-left"></i>
            </a>
            
            <!-- Change template home according to current url last folder name -->
            <span class="template-home">Append</span>

            <!-- Click to change to the next template -->
            <a href="#" title="Next Template: Anyar" target="_top" id="next-template">
                <i class="bi bi-chevron-right"></i>
            </a>
        </div>

        <div class="navigate">
            <!-- Click to navigate to the current URL -->
            <a href="#" target="_blank" title="">
                <i class="bi bi-box-arrow-up-right"></i>
            </a>
            <!-- Change download link to the current URL -->
            <a class="download" href="" title="" target="_blank">
                <i class="bi bi-download"></i>
                <span>Free Download</span>
            </a>
        </div>

    </header>

    <div id="preview">
        <!-- Change src in current URL according to click or press the button -->
        <iframe id="preview-frame" class="preview-desktop" src="http://localhost:8080/web/templates/Anyar/Anyar/" frameborder="0"></iframe>
    </div>

    <!-- Bootstrap Bundle (Popper.js included) -->
    <script src="http://localhost:8080/web/web/assets/node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom Demo JavaScript -->
    <script src="./assets/js/demo.js"></script>
    <script>
        // Array of template names
        const templateNames=["Anyar","Append","Appland","Arsha","Baker","Bethany","Bikin","BizLand","Bootslander","Butterfly","Company","Day","Delicious","Dewi","eNno","Eterna","Flattern","Flexor","FlexStart","Gp","HeroBiz","Hidayah","Impact","iPortfolio","Kelly","Knight","KnightOne","Laura","Logis","Lumia","Mamba","Maxim","Medicio","Medilab","Mentor","Multi","MyResume","NiceAdmin","Nova","OnePage","Personal","PhotoFolio","Plato","Presento","rbp","Remember","Restaurantly","Sailor","Scaffold","Selecao","Serenity","sics","SoftLand","spdl","Techie","Tempo","UpConstruction","Vesperr","Yummy","ZenBlog"];

        // Current template index
        let currentIndex = 0;

        // Function to update iframe source and current template link
        function updatePreview() {
            const baseURL = "http://localhost:8080/web/templates/";
            const templateName = templateNames[currentIndex];

            // Update iframe src
            document.getElementById('preview-frame').setAttribute('src', `${baseURL}${templateName}/${templateName}/`);

            // Update previous template link
            const prevTemplate = document.getElementById('prev-template');
            const prevIndex = (currentIndex - 1 + templateNames.length) % templateNames.length;
            prevTemplate.setAttribute('href', `${baseURL}${templateNames[prevIndex]}/${templateNames[prevIndex]}/`);

            // Update next template link
            const nextTemplate = document.getElementById('next-template');
            const nextIndex = (currentIndex + 1) % templateNames.length;
            nextTemplate.setAttribute('href', `${baseURL}${templateNames[nextIndex]}/${templateNames[nextIndex]}/`);

            // Update navigate link
            const navigateLink = document.querySelector('.navigate a');
            navigateLink.setAttribute('href', `${baseURL}${templateName}/${templateName}/`);

            // Update download link
            const downloadLink = document.querySelector('.download');
            downloadLink.setAttribute('href', `${baseURL}${templateName}/${templateName}/`);

            // Set title of previous template link
            prevTemplate.setAttribute('title', `Prev Template: ${templateNames[prevIndex]}`);

            // Set title of next template link
            nextTemplate.setAttribute('title', `Next Template: ${templateNames[nextIndex]}`);

            // Set title of navigate link
            navigateLink.setAttribute('title', `Navigate to: ${templateName}`);

            // Set title of download link
            downloadLink.setAttribute('title', `Download: ${templateName}`);

            // Update template home span
            document.querySelector('.template-home').textContent = templateName;
        }

        // Update initial preview
        updatePreview();

        // Event listener for clicking the previous template button
        document.getElementById('prev-template').addEventListener('click', function(event) {
            event.preventDefault(); // Prevent default link behavior
            currentIndex = (currentIndex - 1 + templateNames.length) % templateNames.length;
            updatePreview();
        });

        // Event listener for clicking the next template button
        document.getElementById('next-template').addEventListener('click', function(event) {
            event.preventDefault(); // Prevent default link behavior
            currentIndex = (currentIndex + 1) % templateNames.length;
            updatePreview();
        });

        // Event listener for keydown event
        document.addEventListener('keydown', function(event) {
            if (event.key === 'ArrowLeft') {
                // Move to the previous template
                currentIndex = (currentIndex - 1 + templateNames.length) % templateNames.length;
                updatePreview();
            } else if (event.key === 'ArrowRight') {
                // Move to the next template
                currentIndex = (currentIndex + 1) % templateNames.length;
                updatePreview();
            }
        });

    </script>
</body>

</html>
