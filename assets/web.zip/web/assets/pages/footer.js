// footer function 
export default function footer() {
   // form submission 
   
}
footer(); 

// End footer function 