<section id="services" class="container-fluid py-4">
   <h1 class="web-title text-center" data-aos="fade-down">Web design and Development</h1>
   <p class="text-center container" data-aos="zoom-in">
      Our expert team of designers and developers create visually appealing and user-friendly websites tailored to your specific requirements. We leverage the latest web technologies to deliver high-quality, responsive, and scalable websites.
   </p>
   <div class="row">
   <!-- Web Application -->
   <div class="col-lg-3 col-md-6 mb-4">
      <div class="card shadow text-center h-100" data-aos="fade-up-left">
         <div class="card-body ls">
         <i class="fas fa-laptop-code fa-2x mb-3"></i>
         <h5 class="card-title">Web Application</h5>
         <p class="card-text">Interactive online tools enhancing user experiences and productivity.</p>
         </div>
      </div>
   </div>
   <!-- E-Commerce -->
   <div class="col-lg-3 col-md-6 mb-4">
      <div class="card shadow text-center h-100" data-aos="fade-up-right">
         <div class="card-body ls">
         <i class="fas fa-shopping-cart fa-2x mb-3"></i>
         <h5 class="card-title">E-Commerce</h5>
         <p class="card-text">Revolutionizing retail through digital commerce. </p>
         </div>
      </div>
   </div>
   <!-- CMS Development -->
   <div class="col-lg-3 col-md-6 mb-4">
      <div class="card shadow text-center h-100" data-aos="fade-up-left">
         <div class="card-body ls">
         <i class="fas fa-database fa-2x mb-3"></i>
         <h5 class="card-title">CMS Development</h5>
         <p class="card-text">Empowering seamless content management with innovative CMS solutions.</p>
         </div>
      </div>
   </div>
   <!-- API Integration -->
   <div class="col-lg-3 col-md-6 mb-4">
      <div class="card shadow text-center h-100" data-aos="fade-up-right">
         <div class="card-body ls">
         <i class="fas fa-link fa-2x mb-3"></i>
         <h5 class="card-title">API Integration</h5>
         <p class="card-text">Seamlessly connecting systems through powerful API integration.</p>
         </div>
      </div>
   </div>
   </div>
   <div class="row">
   <!-- GCP Management-->
   <div class="col-lg-3 col-md-6 mb-4">
      <div class="card shadow text-center h-100" data-aos="zoom-in-left">
         <div class="card-body ls">
         <i class="fa-solid fa-cloud fa-2x mb-3"></i>
         <h5 class="card-title">GCP Management</h5>
         <p class="card-text">Efficiently managing GCP infrastructure for optimal performance. </p>
         </div>
      </div>
   </div>
   <!-- Firebase -->
   <div class="col-lg-3 col-md-6 mb-4">
      <div class="card shadow text-center h-100" data-aos="fade-down-left">
         <div class="card-body ls">
         <i class="fab fa-google fa-2x mb-3"></i>
         <h5 class="card-title">Firebase hosting</h5>
         <p class="card-text">Effortless web hosting with Firebase's scalable and secure platform. </p>
         </div>
      </div>
   </div>
   <!-- AWS -->
   <div class="col-lg-3 col-md-6 mb-4"> 
      <div class="card shadow text-center h-100" data-aos="fade-down-right">
         <div class="card-body ls">
         <i class="fab fa-aws fa-2x mb-3"></i>
         <h5 class="card-title">AWS Management</h5>
         <p class="card-text">Powerful cloud services with AWS for scalable solutions.</p>
         </div>
      </div>
   </div>
   <!-- API Integration -->
   <div class="col-lg-3 col-md-6 mb-4">
      <div class="card shadow text-center h-100" data-aos="zoom-in-right">
         <div class="card-body ls">
         <i class="fab fa-github fa-2x mb-3"></i>
         <h5 class="card-title">GitHub</h5>
         <p class="card-text">Platform for hosting, sharing, and collaborating on code projects.</p>
         </div>
      </div>
   </div>
   </div>
</section>