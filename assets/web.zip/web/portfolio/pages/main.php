<main id="main">

<!-- ======= About Section ======= -->
<section id="about" class="about pb-0">
  <div class="container">

    <div class="section-title">
      <h2>About</h2>
      <p>I am Deepak Kumar, a seasoned web developer with one year of hands-on experience. My expertise encompasses a comprehensive range of programming languages and frameworks including HTML, CSS, JavaScript, Bootstrap, jQuery, PHP, and MySQL. My focus lies in creating dynamic and user-centered web solutions that seamlessly integrate form and function, reflecting a commitment to excellence in every project.</p>
    </div>

    <div class="row">
      <div class="col-lg-4" data-aos="fade-right">
        <img src="assets/img/deepak.jpg" class="img-fluid" alt="">
      </div>
      <div class="col-lg-8 pt-4 pt-lg-0 content" data-aos="fade-left">
        <h3>UI/UX Designer &amp; Web Developer.</h3>
        <p class="fst-italic">
          I bring ideas to life through pixels and code, making the digital world look and work seamlessly.
        </p>
        <div class="row">
          <div class="col-lg-6">
            <ul>
              <li><i class="bi bi-chevron-right"></i> <strong>Birthday:</strong> <span>3 July 2001</span></li>
              <li><i class="bi bi-chevron-right"></i> <strong>Website:</strong> <span><a href="https://syntway.org/">www.syntway.org</a></span></li>
              <li><i class="bi bi-chevron-right"></i> <strong>Phone:</strong> <span><a href="tel:+918948263861">+91 89482-63861</a></span></li>
              <li><i class="bi bi-chevron-right"></i> <strong>City:</strong> <span>Khaga Fatehpur UP IN-212655</span></li>
            </ul>
          </div>
          <div class="col-lg-6">
            <ul>
              <li><i class="bi bi-chevron-right"></i> <strong>Age:</strong> <span id="age">22</span></li>
              <li><i class="bi bi-chevron-right"></i> <strong>Degree:</strong> <span>Information Technology</span></li>
              <li><i class="bi bi-chevron-right"></i> <strong>E-mail:</strong> <span><a href="mailto:synt.way@gmail.com">synt.way@gmail.com</a></span></li>
              <li><i class="bi bi-chevron-right"></i> <strong>Freelance:</strong> <span>Available</span></li>
            </ul>
          </div>
        </div>
        <p>
          In my professional journey, I've played a pivotal role in crafting captivating and user-friendly websites. With my blend of technical proficiency and a strong design sensibility, I excel in delivering solutions centered around enhancing user experience. Whether I'm developing polished front-end interfaces or fine-tuning backend operations, I derive immense satisfaction from transforming concepts into reality within the digital realm.
        </p>
      </div>
    </div>

  </div>
</section><!-- End About Section -->

<!-- ======= Skills Section ======= -->
<section id="skills" class="skills pb-0">
  <div class="container">

    <div class="section-title">
      <h2>Skills</h2>
      <p>With expertise spanning HTML, CSS, JavaScript, Bootstrap, jQuery, PHP, and MySQL, this professional brings a wealth of technical prowess to the table. Specializing in crafting dynamic and user-centric web designs, they seamlessly integrate form and function, ensuring optimal performance and user experience.</p>
    </div>

    <div class="row skills-content">

      <div class="col-lg-6" data-aos="fade-up">

        <div class="progress">
          <span class="skill">HTML <i class="val">100%</i></span>
          <div class="progress-bar-wrap">
            <div class="progress-bar" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
          </div>
        </div>

        <div class="progress">
          <span class="skill">CSS <i class="val">60%</i></span>
          <div class="progress-bar-wrap">
            <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"></div>
          </div>
        </div>

        <div class="progress">
          <span class="skill">JavaScript <i class="val">85%</i></span>
          <div class="progress-bar-wrap">
            <div class="progress-bar" role="progressbar" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
          </div>
        </div>

        <div class="progress">
          <span class="skill">jQuery <i class="val">55%</i></span>
          <div class="progress-bar-wrap">
            <div class="progress-bar" role="progressbar" aria-valuenow="55" aria-valuemin="0" aria-valuemax="100"></div>
          </div>
        </div>

      </div>

      <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
        
        <div class="progress">
          <span class="skill">PHP <i class="val">95%</i></span>
          <div class="progress-bar-wrap">
            <div class="progress-bar" role="progressbar" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
          </div>
        </div>

        <div class="progress">
          <span class="skill">MySQL <i class="val">89%</i></span>
          <div class="progress-bar-wrap">
            <div class="progress-bar" role="progressbar" aria-valuenow="89" aria-valuemin="0" aria-valuemax="100"></div>
          </div>
        </div>

        <div class="progress">
          <span class="skill">bootstrap <i class="val">50%</i></span>
          <div class="progress-bar-wrap">
            <div class="progress-bar" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
          </div>
        </div>

        <div class="progress">
          <span class="skill">Photoshop <i class="val">55%</i></span>
          <div class="progress-bar-wrap">
            <div class="progress-bar" role="progressbar" aria-valuenow="55" aria-valuemin="0" aria-valuemax="100"></div>
          </div>
        </div>

      </div>

    </div>

  </div>
</section><!-- End Skills Section -->

<!-- ======= Resume Section ======= -->
<section id="resume" class="resume pb-0">
  <div class="container">

    <div class="section-title">
      <h2>Resume</h2>
      <p>Dedicated and results-driven professional with a proven track record of success in web development.I specialize in creating dynamic and user-centric web designs. With a keen eye for detail and a commitment to excellence, I excel in delivering solutions that optimize performance and elevate user experience.</p>
    </div>

    <div class="row">
      <div class="col-lg-6" data-aos="fade-up">
        <h3 class="resume-title">Experience</h3>
        <div class="resume-item pb-0">
          <h4>Web developer</h4>
          <ul>
            <li><a href="http://syntway.org/">Syntway</a></li>
            <li id="durationList">Feb 2023 - Present 1 year 1 month</li>
            <li>Khaga, Uttar Pradesh, India</li>
          </ul>
          <p>Syntway is a leading software company with expertise in revolutionizing educational systems and delivering advanced web development services. Our fervor lies in harnessing technology to reshape the educational arena and deliver sophisticated web solutions.</p>
        </div>

        <h3 class="resume-title">Education</h3>
        <div class="resume-item">
          <h4>High school</h4>
          <h5>2016 - 2018</h5>
          <p><b>Rajaram Inter College Hardon Fatehpur IN 212655</b></p>
          <p>High school art, biology, chemistry, history, mathematics, physics, and science converge. Our journey spans creativity, decoding human civilization, exploring natural phenomena, and unraveling the universe's mysteries.</p>
        </div>
        <div class="resume-item">
          <h4>Intermediate</h4>
          <h5>2018 - 2020</h5>
          <p><b>Janhitkari Inter College Town Khaga Fatehpur IN 212655</b></p>
          <p> Hindi, English, Math, Physics, Chemistry. Explore language, numeracy, and sciences. Delve into literature, linguistic analysis, math concepts, and fundamental laws of physics and chemistry. Join us for a well-rounded educational experience.p>
        </div>
      </div>
      <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
        <h3 class="resume-title">Diploam Courses</h3>
        <div class="resume-item">
          <h4>Advance Diploma in Computer Application</h4>
          <h5>2020 - 2022</h5>
          <p><b>SICS Ailai Road Hardon IN 212655</b></p>
          <ul>
            <li>Advance Diploma in Computer Application (ADCA) offers a comprehensive understanding of computer applications.</li>
            <li>It covers various aspects of computer science, including programming languages, software development, database management, and computer networking.</li>
            <li>Students gain practical skills in areas such as programming, web development, database management, and system administration.</li>
            <li>The program equips individuals with the knowledge and expertise required to pursue careers in the field of information technology.</li>
          </ul>
        </div>
        <div class="resume-item">
          <h4>O'level</h4>
          <h5>2022 - Present</h5>
          <p><b>Nielit New Delhi IN 212655 </b></p>
          <ul>
            <li>NIELIT is an autonomous scientific society under the Indian Ministry of Electronics & Information Technology.</li>
            <li>It offers various courses and certifications in the field of information technology and electronics.
            </li>
            <li>NIELIT aims to promote quality education and skill development in emerging areas of technology.</li>
            <li>The institute provides training, certification, and consultancy services to individuals and organizations.</li>
          </ul>
        </div>
      </div>
    </div>

  </div>
</section><!-- End Resume Section -->

<!-- ======= Services Section ======= -->
<section id="services" class="services pb-0">
  <div class="container">

    <div class="section-title">
      <h2>Services</h2>
      <p>Our expert team of designers and developers create visually appealing and user-friendly websites tailored to your specific requirements. We leverage the latest web technologies to deliver high-quality, responsive, and scalable websites.</p>
    </div>

    <div class="row">
      <div class="col-lg-4 col-md-6 icon-box" data-aos="fade-up">
        <div class="icon"><i class="bi bi-code"></i></div>
        <h4 class="title"><a href="">Web Application</a></h4>
        <p class="description">Web application allows users perform tasks via browser. Hosted on server, built with HTML, CSS, JavaScript, PHP, MySQL. Varies in complexity.</p>
      </div>
      <div class="col-lg-4 col-md-6 icon-box" data-aos="fade-up" data-aos-delay="100">
        <div class="icon"><i class="bi bi-cart"></i></div>
        <h4 class="title"><a href="">E-Commerce</a></h4>
        <p class="description">E-commerce involves online buying and selling of goods and services. It revolutionizes business operations and consumer shopping with convenience and global reach.</p>
      </div>
      <div class="col-lg-4 col-md-6 icon-box" data-aos="fade-up" data-aos-delay="200">
        <div class="icon"><i class="bi bi-database"></i></div>
        <h4 class="title"><a href="">CMS Development</a></h4>
        <p class="description">CMS development involves creating, customizing, and managing content management systems. It streamlines website management, enabling easy content creation, publishing, and updates.</p>
      </div>
      <div class="col-lg-4 col-md-6 icon-box" data-aos="fade-up" data-aos-delay="300">
        <div class="icon"><i class="bi bi-link"></i></div>
        <h4 class="title"><a href="">API Integration</a></h4>
        <p class="description">API integration links software systems via APIs, enabling seamless communication and data sharing. It enhances functionality and automation across platforms, streamlining processes efficiently.</p>
      </div>
      <div class="col-lg-4 col-md-6 icon-box" data-aos="fade-up" data-aos-delay="400">
        <div class="icon"><i class="bi bi-cloud"></i></div>
        <h4 class="title"><a href="">GCP Management</a></h4>
        <p class="description">GCP management involves overseeing resources and services on Google Cloud Platform. It ensures efficient utilization, scalability, security, and optimization of cloud infrastructure and applications.</p>
      </div>
      <div class="col-lg-4 col-md-6 icon-box" data-aos="fade-up" data-aos-delay="500">
        <div class="icon"><i class="bi bi-github"></i></div>
        <h4 class="title"><a href="">GitHub</a></h4>
        <p class="description">GitHub is a platform for hosting, sharing, and collaborating on software development projects using version control. It offers features like code hosting, collaboration, and workflow automation.</p>
      </div>
    </div>

  </div>
</section><!-- End Services Section -->


<!-- ======= Contact Section ======= -->
<section id="contact" class="contact">
  <div class="container">

    <div class="section-title">
      <h2>Contact</h2>
      <div class="row" data-aos="fade-in">

        <div class="col-lg-5 d-flex align-items-stretch">
          <div class="info">
            <div class="address">
              <i class="bi bi-geo-alt"></i>
              <h4>Location:</h4>
              <p>Chak babullapur mohkam khaga fatehpur UP IN-212655</p>
            </div>

            <div class="email">
              <i class="bi bi-envelope"></i>
              <h4>Email:</h4>
              <p>
                <a href="mailto:synt.way@gmail.com">synt.way@gmail.com</a>
              </p>
            </div>

            <div class="phone">
              <i class="bi bi-phone"></i>
              <h4>Call:</h4>
              <p><a href="tel:+918948263861">+91 89482 63861</a></p>
            </div>

            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3594.444610724043!2d81.08145807475877!3d25.722806510212372!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x399b41d970cdcb6d%3A0xe46bfcadc340ac82!2sSyntway!5e0!3m2!1sen!2sin!4v1708160347951!5m2!1sen!2sin" frameborder="0" style="border:0; width: 100%; height: 290px;" allowfullscreen></iframe>

          </div>

        </div>

        <div class="col-lg-7 mt-5 mt-lg-0 d-flex align-items-stretch">
          <form class="needs-validation php-email-form" novalidate action="" method="post" id="emailForm">
            <div class="row">
                <div class="col-md-6 form-group input">
                    <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required>
                    <div class="invalid-feedback">Please enter your First name.</div>
                </div>

                <div class="col-md-6 form-group mt-3 mt-md-0">
                    <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required>
                    <div class="invalid-feedback">Please enter your email address.</div>
                </div>
            </div>

            <div class="form-group mt-3">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" required>
                <div class="invalid-feedback">Please enter your subject.</div>
            </div>

            <div class="form-group mt-3">
                <textarea class="form-control" name="message" rows="6" placeholder="Message" required></textarea>
                <div class="invalid-feedback">Please enter your message.</div>
            </div>
            <!-- loading spinner -->
            <div class="my-3 d-flex justify-content-center">
                <div class="spinner-border text-primary d-none align-self-center" role="status" id="loadingSpinner">
                    <span class="sr-only"></span>
                </div>
            </div>
            <!-- alert message -->
            <div class="my-3">
                <div class="alert alert-success d-none" role="alert" id="successMessage"></div>
                <div class="alert alert-danger d-none" role="alert" id="errorMessage"></div>
            </div>

            <div class="text-center mt-3">
                <button type="submit" class="btn btn-primary">Send Message</button>
            </div>
          </form>

        </div>

      </div>
    </div>
  </div>
</section><!-- End Contact Section -->

</main><!-- End #main -->
