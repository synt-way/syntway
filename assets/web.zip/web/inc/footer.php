   <!-- node_module js file -->
   <script src="./assets/node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
   <script src="./assets/node_modules/typed.js/dist/typed.umd.js"></script>
   <script src="./assets/node_modules/gsap/dist/gsap.min.js"></script>
   <script src="./assets/node_modules/aos/dist/aos.js"></script>
   <script src="./assets/node_modules/glightbox/dist/js/glightbox.min.js"></script>
   <script src="./assets/node_modules/swiper/swiper-bundle.min.js"></script>
   <script src="./assets/node_modules/jquery/dist/jquery.min.js"></script>
   <script src="./assets/node_modules/php-email-form/validate.js"></script>
   
   <!-- custom js file -->
   <script type="module" src="./assets/js/script.js"></script>
</body>
</html>
