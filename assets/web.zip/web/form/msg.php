<?php function msg($classes, $message) {
    echo '
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Syntway</title>
            <link rel="shortcut icon" href="../assets/img/logo.png" type="image/x-icon">
            <link rel="apple-touch-icon" href="../assets/img/logo.png">
            
            <!-- Bootstrap CSS -->
            <link rel="stylesheet" href="../assets/node_modules/bootstrap/dist/css/bootstrap.min.css">
        </head>
        <body>
        
            <!-- sign in section -->
            <div class="d-flex align-items-top mt-3">
            <div class="container-fluid text-center">
                <div class="row justify-content-center">
                    <div class="col-lg-4 col-md-6">
                        <div class="alert alert-'.$classes.'" role="alert">' .$message.'</div>
                    </div>
                </div>
            </div>
            </div>
            
        <!-- Bootstrap JS (optional) -->
        <script src="../assets/node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
        
        </body>
        </html>  
    '; 
} ?>
