<?php 
   include './form/contact-form/mail.php'; // contact form handling 
   include './inc/header.php'; // include header section 
   include './pages/navbar.php'; // navbar section 
   include './pages/faq.php'; // faq section 
   include './pages/contact.php'; // contact section 
   include './pages/footer.php'; // footer section 
   include './inc/footer.php'; // include footer section 
?>