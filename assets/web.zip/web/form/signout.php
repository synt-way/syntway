<?php
include './db_connection.php'; // database connection 

session_start();

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    // Redirect to login page or display an error message
    header("Location: ../"); // Adjust the redirection URL as needed
    exit(); // Stop further execution of the script
}

// Check if the logout form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["confirm_logout"])) {
    // Clear all session variables
    session_unset();

    // Destroy the session
    session_destroy();

    // Redirect to home page with logout message
    msg('success', 'You\'re Successfully Sign Out'); 
    header('refresh: 1; url= ../'); 

    exit();
}
    // show alert for confirmation 
    alert('Logout', 'Are you sure you want to logout ?', 'confirm_logout', 'Logout', 'text-danger'); 
?>

