<?php
include './db_connection.php'; // database connection 

session_start();

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    // Redirect to login page or display an error message
    header("Location: ../"); // Adjust the redirection URL as needed
    exit(); // Stop further execution of the script
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Extract form data
    $newpassword = $_POST['newpassword']; 
    $repeatpassword = $_POST['repeatpassword']; 
    $username = $_SESSION['username']; // Get username from session

    // Check if passwords match
    if ($repeatpassword === $newpassword) {
        // Prepare and bind parameters to prevent SQL injection
        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE username = ?");
        $stmt->bind_param("ss", $newpassword, $username);

        // Execute the statement
        if ($stmt->execute()) {
            // Password successfully updated
            msg('success', 'Password successfully updated.');
            header("refresh:1; url=../user/users-profile.php");
            exit();
        } else {
            // Error updating password
            msg('danger', 'Failed to update password. Please try again');
            header("refresh:1; url=../user/users-profile.php");
            exit();
        }
    } else {
        // Passwords do not match
        msg('danger', 'Password do not match'); 
        header("refresh:1; url=../user/users-profile.php");
        exit();
    }
} else {
    // Form not submitted
    msg('danger', 'No data submitted. Please try again'); 
    header("refresh:1; url=../user/users-profile.php");
    exit();
}

$conn->close();
?>
