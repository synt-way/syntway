<?php
include './db_connection.php'; // database connection 
 
session_start();

// Form submission handling
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Check credentials
    $sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
    $result = $conn->query($sql);
    if ($result->num_rows == 1) {
        // Store username in session
        $_SESSION['username'] = $username;
           
        // Redirect to dashboard
        msg('success', 'You have successfully Sign In'); 
        header('refresh: 1; url=../user/'); 
        exit();
    } else {
      msg('danger', 'Invalid username or password'); 
      header('refresh: 1; url=../signin.php'); 
    }
}

$conn->close();
?>
