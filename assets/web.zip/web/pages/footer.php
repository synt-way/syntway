<!-- footer section -->
<footer id="footer">

   <div class="footer-top bg-black pt-5">
      <div class="container-fluid bg-black">
            <div class="row">

               <div class="col-lg-2 col-md-4 footer-contact">
                  <h3 data-aos="fade-right">Syntway</h3>
                  <p data-aos="fade-right" class="mb-3">
                     Chak babullapur mohkam <br>
                     Khaga Fatehpur UP <br>
                     India - 212655 <br>
                  </p>
                  <div data-aos="fade-right">
                     <strong>Phone:</strong> <a href="tel:+918948263861">+91 89482-63861</a><br>
                     <strong>Email:</strong> <a href="mailto:synt.way@gmail.com">synt.way@gmail.com</a><br>
                  </div>
               </div>

               <div class="col-lg-2 col-md-4 footer-links">
                  <h4 data-aos="fade-right">Useful Links</h4>
                  <ul data-aos="fade-right">
                     <li data-aos="fade-right"><i class="bi bi-chevron-right"></i></i> <a href="./">Home</a></li>
                     <li data-aos="fade-right"><i class="bi bi-chevron-right"></i></i> <a href="./about.php">About us</a></li>
                     <li data-aos="fade-right"><i class="bi bi-chevron-right"></i></i> <a href="./services.php">Services</a></li>
                     <li data-aos="fade-right"><i class="bi bi-chevron-right"></i></i> <a href="./terms.php">Terms of service</a></li>
                     <li><i class="bi bi-chevron-right"></i></i> <a href="./privacy.php">Privacy policy</a></li>
                  </ul>
               </div>

               <div class="col-lg-2 col-md-4 footer-links">
                  <h4 data-aos="fade-right">Services</h4>
                  <ul data-aos="fade-right">
                     <li data-aos="fade-right"><i class="bi bi-chevron-right"></i></i> <a href="#">Web Development</a></li>
                     <li data-aos="fade-right"><i class="bi bi-chevron-right"></i></i> <a href="#">Web Design</a></li>
                     <li data-aos="fade-right"><i class="bi bi-chevron-right"></i></i> <a href="#">Product Management</a></li>
                     <li data-aos="fade-right"><i class="bi bi-chevron-right"></i></i> <a href="#">Marketing</a></li>
                     <li><i class="bi bi-chevron-right"></i></i> <a href="#">Graphic Design</a></li>
                  </ul>
               </div>

               <div class="col-lg-2 col-md-4 footer-links">
                  <h4 data-aos="fade-right">Learning </h4>
                  <ul data-aos="fade-right">
                     <li data-aos="fade-right"><i class="bi bi-chevron-right"></i></i> <a href="#">Home</a></li>
                     <li data-aos="fade-right"><i class="bi bi-chevron-right"></i></i> <a href="#">About us</a></li>
                     <li data-aos="fade-right"><i class="bi bi-chevron-right"></i></i> <a href="#">Services</a></li>
                     <li data-aos="fade-right"><i class="bi bi-chevron-right"></i></i> <a href="#">Terms of service</a></li>
                     <li><i class="bi bi-chevron-right"></i></i> <a href="#">Privacy policy</a></li>
                  </ul>
               </div>

               <div class="col-lg-2 col-md-4 footer-links">
                  <h4 data-aos="fade-right">Management</h4>
                  <ul data-aos="fade-right">
                     <li data-aos="fade-right"><i class="bi bi-chevron-right"></i></i> <a href="#">Web Design</a></li>
                     <li data-aos="fade-right"><i class="bi bi-chevron-right"></i></i> <a href="#">Web Development</a></li>
                     <li data-aos="fade-right"><i class="bi bi-chevron-right"></i></i> <a href="#">Product Management</a></li>
                     <li data-aos="fade-right"><i class="bi bi-chevron-right"></i></i> <a href="#">Marketing</a></li>
                     <li><i class="bi bi-chevron-right"></i></i> <a href="#">Graphic Design</a></li>
                  </ul>
               </div>

               <div class="col-lg-2 col-md-4 footer-newsletter">
                  <h4 data-aos="fade-right">Join Our Newsletter</h4>
                  <p data-aos="fade-right">Innovative solutions define our cutting-edge software company. Join our journey!</p>
                  <form action="" method="post" data-aos="fade-right">
                     <input type="email" name="email" placeholder="E-mail address">
                     <input type="submit" value="Join">
                  </form>
               </div>

            </div>
         </div>
         </div>

         <div class="container-fluid d-md-flex py-3 bg-black">

            <div class="me-md-auto text-center text-md-start">
               <div class="copyright">
                  <span>&COPY; Copyright <strong>Syntway</strong>. All Rights Reserved</span>
               </div>
               <!-- <div class="credits">
                  Designed by <a href="https://syntway.org/">Syntway</a>
               </div> -->
            </div>
            <div class="social-links text-center text-md-right pt-3 pt-md-0">
               <a href="https://twitter.com/synt_way" class="twitter"><i class="bi bi-twitter"></i></a>
               <a href="https://www.facebook.com/profile.php?id=100093432069582" class="facebook"><i class="bi bi-facebook"></i></a>
               <a href="https://g.dev/syntway" class="google"><i class="bi bi-google"></i></a>
               <a href="https://www.linkedin.com/in/syntway" class="linkedin"><i class="bi bi-linkedin"></i></a>
               <a href="https://github.com/synt-way" class="github"><i class="bi bi-github"></i></a>
            </div>

         </div>
      </div>
   </div>

</footer>
<!-- End footer section -->