<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Portfolio</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="./assets/img/logo.png" rel="icon">
  <link href="./assets/img/logo.png" rel="icon">

  <!-- Vendor CSS Files -->
  <link href="../assets/node_modules/aos/dist/aos.css" rel="stylesheet">
  <link href="../assets/node_modules/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/node_modules/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/node_modules/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="../assets/node_modules/glightbox/dist/css/glightbox.min.css" rel="stylesheet">
  <link href="../assets/node_modules/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="./assets/css/style.css" rel="stylesheet">

</head>

<body>