<?php
   include './db_connection.php'; // database connection 
   
   // Form submission handling
   if ($_SERVER["REQUEST_METHOD"] == "POST") {
      $fname = $_POST['fname'];
      $lname = $_POST['lname']; 
      $username = $_POST['username'];
      $password = $_POST['password'];

      // Check for duplicate username or email
      $check_query = "SELECT * FROM users WHERE username='$username'";
      $result = $conn->query($check_query);

      if ($result->num_rows > 0) {
         // Redirect to singup page after 5 seconds
         header("refresh: 1; url=../signup.php");
         msg('danger', 'Username already exist');
      } else {
         // Insert data into database
         $sql = "INSERT INTO users (fname, lname, username, password) VALUES ('$fname', '$lname', '$username','$password')";
         
         if ($conn->query($sql) === TRUE) {
               session_start();
               // Store username in session
               $_SESSION['username'] = $username; 
               // Set registration success session variable
               $_SESSION['registration_success'] = true; 

               msg('success', 'Congratulations! You have successfully registered.'); 
               header("refresh: 1; url=../user/"); // Redirect to user-profile after 5 seconds
         } else {
               msg('danger', 'Error: ' . $sql . '<br>' . $conn->error);
         }
      }
   }

   $conn->close();
?>
