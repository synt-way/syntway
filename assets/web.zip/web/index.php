<?php 
   include './inc/header.php'; // include header section 
   include './pages/hero.php'; // hero section 
   include './pages/navbar.php'; // navbar section 
   include './pages/ams.php'; // ams (about, mission, services) section 
   include './pages/whychoose.php'; // why choose us section 
   include './pages/team.php'; // team section 
   include './pages/testimonial.php'; // testimonial section j
   include './pages/footer.php'; // footer section 
   include './inc/footer.php'; // include footer section 
?>