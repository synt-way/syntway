// whychoose function 
export default function whychoose() {
   // do something
}
whychoose(); 

// End whychoose function 