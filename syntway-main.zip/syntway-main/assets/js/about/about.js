// import about.js file from home/module/
import * as about from '../home/module/about.js';
// import whychoose.js file home/module/
import * as whychoose from '../home/module/whychoose.js';
// import services.js file home/module/
import * as services from '../home/module/services.js';
