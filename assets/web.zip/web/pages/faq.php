<main id="faq" class="main container-fluid pt-4">
    
  <h1 class="web-title text-center pb-4">Frequently Asked Questions</h1>

  <div class="row">
    <div class="col-md-6">
      <!-- Basic Question -->
      <div class="card basic" data-aos="fade-up-left">
        <div class="card-body">
          <h5 class="card-title">Basic Questions</h5>

          <div>
            <h6>1. What is Syntway?</h6>
            <p>Syntway is a leading provider of Education System Solutions and Web Design & Development services. We specialize in creating innovative and customized solutions to meet the unique needs of educational institutions and businesses.</p>
          </div>

          <div class="pt-2">
            <h6>2. What Education System Solutions do you offer?</h6>
            <p>We offer a comprehensive range of Education System Solutions, including Learning Management Systems (LMS), Student Information Systems (SIS), School Management Systems, Online Examination Platforms, Virtual Classrooms, and more.</p>
          </div>

          <div class="pt-2">
            <h6>3. Do you cater to different educational institutions?</h6>
            <p>Yes, we cater to a wide range of educational institutions, including schools, colleges, universities, online learning platforms, corporate training centers, and other e-learning initiatives.</p>
          </div>

        </div>
      </div><!-- End Basic Question -->

      <!-- F.A.Q Group 1 -->
      <div class="card" data-aos="fade-down-left">
        <div class="card-body">
          <h5 class="card-title">Our services related questions</h5>

          <div class="accordion accordion-flush" id="faq-group-1">

            <div class="accordion-item">
              <h2 class="accordion-header">
                <button class="accordion-button collapsed" data-bs-target="#faqsOne-1" type="button" data-bs-toggle="collapse">
                  1. Does Syntway offer custom web design and development services?
                </button>
              </h2>
              <div id="faqsOne-1" class="accordion-collapse collapse" data-bs-parent="#faq-group-1">
                <div class="accordion-body">
                  Yes, Syntway specializes in creating custom websites tailored to the unique needs and preferences of each client. We develop responsive, user-friendly, and visually appealing websites.
                </div>
              </div>
            </div>

            <div class="accordion-item">
              <h2 class="accordion-header">
                <button class="accordion-button collapsed" data-bs-target="#faqsOne-2" type="button" data-bs-toggle="collapse">
                  2. What technologies does Syntway use for web development?
                </button>
              </h2>
              <div id="faqsOne-2" class="accordion-collapse collapse" data-bs-parent="#faq-group-1">
                <div class="accordion-body">
                  Syntway utilizes the latest web development technologies, including HTML5, CSS3, JavaScript, Bootstrap, React, Angular, and PHP, to build robust and modern websites.
                </div>
              </div>
            </div>

            <div class="accordion-item">
              <h2 class="accordion-header">
                <button class="accordion-button collapsed" data-bs-target="#faqsOne-3" type="button" data-bs-toggle="collapse">
                  3. Can Syntway redesign an existing website?
                </button>
              </h2>
              <div id="faqsOne-3" class="accordion-collapse collapse" data-bs-parent="#faq-group-1">
                <div class="accordion-body">
                  Yes, we offer website redesign services to refresh and modernize existing websites, incorporating new features and optimizing user experience.
                </div>
              </div>
            </div>

            <div class="accordion-item">
              <h2 class="accordion-header">
                <button class="accordion-button collapsed" data-bs-target="#faqsOne-4" type="button" data-bs-toggle="collapse">
                  4. Is Syntway experienced in e-commerce website development?
                </button>
              </h2>
              <div id="faqsOne-4" class="accordion-collapse collapse" data-bs-parent="#faq-group-1">
                <div class="accordion-body">
                  Absolutely! Syntway has extensive experience in developing secure and efficient e-commerce websites, including online stores, shopping carts, and payment gateway integration.
                </div>
              </div>
            </div>

            <div class="accordion-item">
              <h2 class="accordion-header">
                <button class="accordion-button collapsed" data-bs-target="#faqsOne-5" type="button" data-bs-toggle="collapse">
                  5. Does Syntway provide website maintenance services?
                </button>
              </h2>
              <div id="faqsOne-5" class="accordion-collapse collapse" data-bs-parent="#faq-group-1">
                <div class="accordion-body">
                  Yes, we offer website maintenance plans to ensure that your website is regularly updated, secure, and functioning optimally.
                </div>
              </div>
            </div>

          </div>

        </div>
      </div><!-- End F.A.Q Group 1 -->

    </div>

    <div class="col-md-6">

      <!-- F.A.Q Group 2 -->
      <div class="card" data-aos="fade-up-right">
        <div class="card-body">
          <h5 class="card-title">Education related questions</h5>

          <div class="accordion accordion-flush" id="faq-group-2">

            <div class="accordion-item">
              <h2 class="accordion-header">
                <button class="accordion-button collapsed" data-bs-target="#faqsTwo-1" type="button" data-bs-toggle="collapse">
                  Cumque voluptatem recusandae blanditiis?
                </button>
              </h2>
              <div id="faqsTwo-1" class="accordion-collapse collapse" data-bs-parent="#faq-group-2">
                <div class="accordion-body">
                  Ut quasi odit odio totam accusamus vero eius. Nostrum asperiores voluptatem eos nulla ab dolores est asperiores iure. Quo est quis praesentium aut maiores. Corrupti sed aut expedita fugit vero dolorem. Nemo rerum sapiente. A quaerat dignissimos.
                </div>
              </div>
            </div>

            <div class="accordion-item">
              <h2 class="accordion-header">
                <button class="accordion-button collapsed" data-bs-target="#faqsTwo-2" type="button" data-bs-toggle="collapse">
                  Provident beatae eveniet placeat est aperiam repellat adipisci?
                </button>
              </h2>
              <div id="faqsTwo-2" class="accordion-collapse collapse" data-bs-parent="#faq-group-2">
                <div class="accordion-body">
                  In minus quia impedit est quas deserunt deserunt et. Nulla non quo dolores minima fugiat aut saepe aut inventore. Qui nesciunt odio officia beatae iusto sed voluptatem possimus quas. Officia vitae sit voluptatem nostrum a.
                </div>
              </div>
            </div>

            <div class="accordion-item">
              <h2 class="accordion-header">
                <button class="accordion-button collapsed" data-bs-target="#faqsTwo-3" type="button" data-bs-toggle="collapse">
                  Minus aliquam modi id reprehenderit nihil?
                </button>
              </h2>
              <div id="faqsTwo-3" class="accordion-collapse collapse" data-bs-parent="#faq-group-2">
                <div class="accordion-body">
                  Voluptates magni amet enim perspiciatis atque excepturi itaque est. Sit beatae animi incidunt eum repellat sequi ea saepe inventore. Id et vel et et. Nesciunt itaque corrupti quia ducimus. Consequatur maiores voluptatum fuga quod ut non fuga.
                </div>
              </div>
            </div>

            <div class="accordion-item">
              <h2 class="accordion-header">
                <button class="accordion-button collapsed" data-bs-target="#faqsTwo-4" type="button" data-bs-toggle="collapse">
                  Quaerat qui est iusto asperiores qui est reiciendis eos et?
                </button>
              </h2>
              <div id="faqsTwo-4" class="accordion-collapse collapse" data-bs-parent="#faq-group-2">
                <div class="accordion-body">
                  Numquam ut reiciendis aliquid. Quia veritatis quasi ipsam sed quo ut eligendi et non. Doloremque sed voluptatem at in voluptas aliquid dolorum.
                </div>
              </div>
            </div>

            <div class="accordion-item">
              <h2 class="accordion-header">
                <button class="accordion-button collapsed" data-bs-target="#faqsTwo-5" type="button" data-bs-toggle="collapse">
                  Laboriosam asperiores eum?
                </button>
              </h2>
              <div id="faqsTwo-5" class="accordion-collapse collapse" data-bs-parent="#faq-group-2">
                <div class="accordion-body">
                  Aut necessitatibus maxime quis dolor et. Nihil laboriosam molestiae qui molestias placeat corrupti non quo accusamus. Nemo qui quis harum enim sed. Aliquam molestias pariatur delectus voluptas quidem qui rerum id quisquam. Perspiciatis voluptatem voluptatem eos. Vel aut minus labore at rerum eos.
                </div>
              </div>
            </div>

          </div>

        </div>
      </div><!-- End F.A.Q Group 2 -->

      <!-- F.A.Q Group 3 -->
      <div class="card" data-aos="fade-down-right">
        <div class="card-body">
          <h5 class="card-title">Company related questions</h5>

          <div class="accordion accordion-flush" id="faq-group-3">

            <div class="accordion-item">
              <h2 class="accordion-header">
                <button class="accordion-button collapsed" data-bs-target="#faqsThree-1" type="button" data-bs-toggle="collapse">
                  Assumenda doloribus est fugiat sint incidunt animi totam nisi?
                </button>
              </h2>
              <div id="faqsThree-1" class="accordion-collapse collapse" data-bs-parent="#faq-group-3">
                <div class="accordion-body">
                  Ut quasi odit odio totam accusamus vero eius. Nostrum asperiores voluptatem eos nulla ab dolores est asperiores iure. Quo est quis praesentium aut maiores. Corrupti sed aut expedita fugit vero dolorem. Nemo rerum sapiente. A quaerat dignissimos.
                </div>
              </div>
            </div>

            <div class="accordion-item">
              <h2 class="accordion-header">
                <button class="accordion-button collapsed" data-bs-target="#faqsThree-2" type="button" data-bs-toggle="collapse">
                  Consequatur saepe explicabo odio atque nisi?
                </button>
              </h2>
              <div id="faqsThree-2" class="accordion-collapse collapse" data-bs-parent="#faq-group-3">
                <div class="accordion-body">
                  In minus quia impedit est quas deserunt deserunt et. Nulla non quo dolores minima fugiat aut saepe aut inventore. Qui nesciunt odio officia beatae iusto sed voluptatem possimus quas. Officia vitae sit voluptatem nostrum a.
                </div>
              </div>
            </div>

            <div class="accordion-item">
              <h2 class="accordion-header">
                <button class="accordion-button collapsed" data-bs-target="#faqsThree-3" type="button" data-bs-toggle="collapse">
                  Voluptates vel est fugiat molestiae rem sit eos sint?
                </button>
              </h2>
              <div id="faqsThree-3" class="accordion-collapse collapse" data-bs-parent="#faq-group-3">
                <div class="accordion-body">
                  Voluptates magni amet enim perspiciatis atque excepturi itaque est. Sit beatae animi incidunt eum repellat sequi ea saepe inventore. Id et vel et et. Nesciunt itaque corrupti quia ducimus. Consequatur maiores voluptatum fuga quod ut non fuga.
                </div>
              </div>
            </div>

            <div class="accordion-item">
              <h2 class="accordion-header">
                <button class="accordion-button collapsed" data-bs-target="#faqsThree-4" type="button" data-bs-toggle="collapse">
                  Ab ipsa cum autem voluptas doloremque velit?
                </button>
              </h2>
              <div id="faqsThree-4" class="accordion-collapse collapse" data-bs-parent="#faq-group-3">
                <div class="accordion-body">
                  Numquam ut reiciendis aliquid. Quia veritatis quasi ipsam sed quo ut eligendi et non. Doloremque sed voluptatem at in voluptas aliquid dolorum.
                </div>
              </div>
            </div>

            <div class="accordion-item">
              <h2 class="accordion-header">
                <button class="accordion-button collapsed" data-bs-target="#faqsThree-5" type="button" data-bs-toggle="collapse">
                  Aliquam magni ducimus facilis numquam dolorum harum eveniet iusto?
                </button>
              </h2>
              <div id="faqsThree-5" class="accordion-collapse collapse" data-bs-parent="#faq-group-3">
                <div class="accordion-body">
                  Aut necessitatibus maxime quis dolor et. Nihil laboriosam molestiae qui molestias placeat corrupti non quo accusamus. Nemo qui quis harum enim sed. Aliquam molestias pariatur delectus voluptas quidem qui rerum id quisquam. Perspiciatis voluptatem voluptatem eos. Vel aut minus labore at rerum eos.
                </div>
              </div>
            </div>

          </div>

        </div>
      </div><!-- End F.A.Q Group 3 -->

    </div>

  </div>

</main><!-- End #main -->