<?php 
   include './inc/header.php'; // include header section 
   include './pages/signup.php'; // signup section 
   include './inc/footer.php'; // include footer section 
?>