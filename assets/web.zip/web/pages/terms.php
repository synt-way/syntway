<div class="container-fluid py-3">
   <h1 class="web-title">Syntway Terms and Conditions</h1>
   <div class="body-text">
      <h5 class="section-title">Introduction</h5>
      <p>Welcome to Syntway. These terms and conditions outline the rules and regulations for the use of Syntway's Website, located at www.syntway.org. By accessing this website, we assume you accept these terms and conditions. Do not continue to use Syntway if you do not agree to take all of the terms and conditions stated on this page.</p>
      
      <h5 class="section-title">Intellectual Property Rights</h5>
      <p>Other than the content you own, under these terms, Syntway and/or its licensors own all the intellectual property rights and materials contained in this Website. You are granted limited license only for purposes of viewing the material contained on this Website.</p>
      
      <h5 class="section-title">Restrictions</h5>
      <p>You are specifically restricted from all of the following:</p>
      <ul>
         <li>Publishing any Website material in any other media;</li>
         <li>Selling, sublicensing and/or otherwise commercializing any Website material;</li>
         <li>Publicly performing and/or showing any Website material;</li>
         <li>Using this Website in any way that is or may be damaging to this Website;</li>
         <li>Using this Website in any way that impacts user access to this Website;</li>
         <li>Using this Website contrary to applicable laws and regulations, or in any way may cause harm to the Website, or to any person or business entity;</li>
         <li>Engaging in any data mining, data harvesting, data extracting or any other similar activity in relation to this Website;</li>
         <li>Using this Website to engage in any advertising or marketing.</li>
      </ul>
      
      <h5 class="section-title">Your Content</h5>
      <p>In these Website Standard Terms and Conditions, "Your Content" shall mean any audio, video text, images or other material you choose to display on this Website. By displaying Your Content, you grant Syntway a non-exclusive, worldwide irrevocable, sub licensable license to use, reproduce, adapt, publish, translate and distribute it in any and all media.</p>
      
      <h5 class="section-title">Disclaimer</h5>
      <p>This Website is provided "as is," with all faults, and Syntway expresses no representations or warranties, of any kind related to this Website or the materials contained on this Website. Also, nothing contained on this Website shall be interpreted as advising you.</p>
      
      <h5 class="section-title">Governing Law & Jurisdiction</h5>
      <p>These terms and conditions will be governed by and construed in accordance with the laws of the State of [Your State], and you submit to the non-exclusive jurisdiction of the state and federal courts located in [Your State] for the resolution of any disputes.</p>
   </div>
</div>
