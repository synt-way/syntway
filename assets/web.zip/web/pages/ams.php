<!-- About section -->
<div class="container-fluid pt-4 pb-2" id="about">
   <div class="row py-2">
      <div class="col-md-6 text-center" data-aos="fade-up-left">
         <h1 class="web-title">About Us</h1>
         <p>Syntway is an Software company specializing in the education system and web development services. We are
            passionate about leveraging technology to transform the educational landscape and provide cutting-edge web
            solutions.</p>
      </div>

      <div class="col-md-6 text-center" data-aos="fade-up-right">
         <h1 class="web-title">Our Mission</h1>
         <p>Our mission is to empower educational institutions with innovative technologies that enhance the learning
            experience. We strive to deliver exceptional web development solutions that meet our clients' unique needs
            and drive their success.</p>
      </div>
   </div>

   <div class="text-center container" data-aos="fade-down">
      <h1 class="web-title">Our Services</h1>
      <p class="">We specialize in creating innovative and customized solutions to meet the unique needs of educational institutions and businesses.We offer a comprehensive range of Education System Solutions, including Learning Management Systems (LMS), Student Information Systems (SIS), School Management Systems, Online Examination Platforms, Virtual Classrooms, and more.</p>
   </div>
</div>