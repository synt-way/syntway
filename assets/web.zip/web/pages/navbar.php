<nav class="sticky-top navbar navbar-expand-md bg-black" aria-label="Offcanvas navbar large">
   <div class="container-fluid">
      <!-- logo and branding -->
      <!-- <img src="assets/img/logo.png" alt="" width="40" height="40" class="img-fluid"> -->
      <a class="navbar-brand" href="./">Syntway</a>
      
      <!-- toggler button -->
      <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar2" aria-controls="offcanvasNavbar2" aria-label="Toggle navigation">
         <i class="bi mobile-nav-toggle bi-list"></i>
      </button>

      <!-- navbar body -->
      <div class="offcanvas offcanvas-end text-bg-dark bg-black" tabindex="-1" id="offcanvasNavbar2" aria-labelledby="offcanvasNavbar2Label">
         
         <!-- Offcanvas header -->
         <div class="offcanvas-header py-2">
            <h5 class="offcanvas-title" id="offcanvasNavbar2Label">SYNTWAY</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
         </div>

         <!-- navbar items -->
         <div class="offcanvas-body pt-0">
            <ul class="navbar-nav justify-content-end flex-grow-1">
               <li class="nav-item">
                  <a class="nav-link" href="./">Home</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="./about.php">About</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="./services.php">Services</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="./learning.php">Learning</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="./portfolio/" target="_blank">Portfolio</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="./demo.php" target="_blank">Demo</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="./contact.php">Contact</a>
               </li>

               <!-- social icons -->
               <div class="nav-link social-icon">
                  <a href="https://twitter.com/synt_way" class="twitter"><i class="bi bi-twitter"></i></a>
                  <a href="https://www.facebook.com/profile.php?id=100093432069582" class="facebook"><i class="bi bi-facebook"></i></a>
                  <a href="https://www.linkedin.com/in/syntway" class="linkedin"><i class="bi bi-linkedin"></i></a>
                  <a href="https://github.com/synt-way" class="github"><i class="bi bi-github"></i></a>
               </div>   
            </ul>
         </div>
      </div>
   </div>
  </nav>
  <!-- End navbar section -->
