<section id="learning" class="py-4 container-fluid">
  <h1 class="text-center web-title" data-aos="fade-down">Education System Solutions</h1>
  <p class="container text-center" data-aos="zoom-in">
    We offer a range of education system solutions including learning management systems, e-learning platforms, and student information systems. Our solutions streamline administrative tasks and foster interactive learning experiences.
  </p>
  <div class="row">
    <!-- HTML -->
    <div class="col-lg-3 col-md-6 mb-4">
      <div class="card shadow text-center h-100" data-aos="fade-up-left">
        <div class="card-body ls">
          <i class="fab fa-html5 fa-2x mb-3"></i>
          <h5 class="card-title">HTML</h5>
          <p class="card-text">Building web pages with HTML's structured markup language.</p>
        </div>
      </div>
    </div>
    <!-- CSS -->
    <div class="col-lg-3 col-md-6 mb-4">
      <div class="card shadow text-center h-100" data-aos="fade-up-right">
        <div class="card-body ls">
          <i class="fab fa-css3-alt fa-2x mb-3"></i>
          <h5 class="card-title">CSS</h5>
          <p class="card-text">Cascading Style Sheets - Beautifying web pages with creative designs.</p>
        </div>
      </div>
    </div>
    <!-- JavaScript -->
    <div class="col-lg-3 col-md-6 mb-4">
      <div class="card shadow text-center h-100" data-aos="fade-up-left">
        <div class="card-body ls">
          <i class="fab fa-js fa-2x mb-3"></i>
          <h5 class="card-title">JavaScript</h5>
          <p class="card-text">Versatile scripting language powering interactive web pages.</p>
        </div>
      </div>
    </div>
    <!-- Bootstrap -->
    <div class="col-lg-3 col-md-6 mb-4">
      <div class="card shadow text-center h-100" data-aos="fade-up-right">
        <div class="card-body ls">
          <i class="fab fa-bootstrap fa-2x mb-3"></i>
          <h5 class="card-title">Bootstrap</h5>
          <p class="card-text">Responsive front-end framework for modern web development.</p>
        </div>
      </div>
    </div>
  </div>

  <div class="row">
    <!-- HTML -->
    <div class="col-lg-3 col-md-6 mb-4">
      <div class="card shadow text-center h-100" data-aos="zoom-in-left">
        <div class="card-body ls">
          <i class="fab fa-js fa-2x mb-3"></i>
          <h5 class="card-title">jQuery</h5>
          <p class="card-text">Simplifies client-side scripting for dynamic HTML interactions.</p>
        </div>
      </div>
    </div>
    <!-- CSS -->
    <div class="col-lg-3 col-md-6 mb-4">
      <div class="card shadow text-center h-100" data-aos="fade-down-left">
        <div class="card-body ls">
          <i class="fab fa-php fa-2x mb-3"></i>
          <h5 class="card-title">PHP</h5>
          <p class="card-text">Server-side scripting language for dynamic web page generation.</p>
        </div>
      </div>
    </div>
    <!-- JavaScript -->
    <div class="col-lg-3 col-md-6 mb-4">
      <div class="card shadow text-center h-100" data-aos="fade-down-right">
        <div class="card-body ls">
          <i class="fas fa-database fa-2x mb-3"></i>
          <h5 class="card-title">MySQL</h5>
          <p class="card-text">Popular relational database management system for storing </p>
        </div>
      </div>
    </div>
    <!-- Bootstrap -->
    <div class="col-lg-3 col-md-6 mb-4">
      <div class="card shadow text-center h-100" data-aos="zoom-in-right">
        <div class="card-body ls">
          <i class="fab fa-angular fa-2x mb-3"></i>
          <h5 class="card-title">Angular</h5>
          <p class="card-text">Framework for building dynamic, single-page web applications.</p>
        </div>
      </div>
    </div>
  </div>

</section>
