<?php function alert($title, $message, $name, $value, $class) {
   echo '
      <!DOCTYPE html>
      <html lang="en">
      <head>
         <meta charset="UTF-8">
         <meta name="viewport" content="width=device-width, initial-scale=1.0">
         <title>Syntway</title>
         <link rel="shortcut icon" href="../assets/img/logo.png" type="image/x-icon">
         <link rel="apple-touch-icon" href="../assets/img/logo.png">
         <!-- Bootstrap CSS -->
         <link rel="stylesheet" href="../assets/node_modules/bootstrap/dist/css/bootstrap.min.css">
         <style>
            .card {
                  box-shadow: 0px 0px 12px 0px rgba(0, 0, 0, 0.15);
                  border: 0; 
            }

            .title {
                  font-size: 18px;
                  font-weight: 400;
                  color: #012970;
            }
         </style>
      </head>
      <body class="d-flex align-items-center justify-content-center vh-100 container-fluid">

      <div class="text-center col-md-6 col-lg-4">
         <!-- Display confirmation message and form -->
         <div class="card">
            <div class="card-header">
                  <h1 class="title m-0">'.$title.'</h1>
            </div>
            <div class="card-body">
                  <p class="card-text '.$class.'">'.$message.'</p>
                  <form method="post">
                     <div class="form-group">
                        <input type="submit" name="'.$name.'" value="'.$value.'" class="btn btn-outline-danger btn-sm">
                        <a href="../user/" class="btn btn-outline-success btn-sm">Cancel</a>
                     </div>
                  </form>
            </div>
         </div>
      </div>

      <!-- Bootstrap JS (optional) -->
      <script src="../assets/node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>

      </body>
      </html>
   ';
} ?>
