  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="container">
      <div class="credits  text-start">
        Designed by <a href="https://syntway.org/">Syntway</a>
      </div>
    </div>
  </footer><!-- End  Footer -->
