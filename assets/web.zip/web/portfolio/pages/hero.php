  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex flex-column justify-content-center align-items-center">
    <div class="hero-container" data-aos="fade-in">
      <h1>Deepak Kumar</h1>
      <p>I'm a <span class="typed" data-typed-items="Web designer, Web developer, Freelancer, Graphics designer"></span></p>
    </div>
  </section><!-- End Hero -->
