<!DOCTYPE html>
<html lang="en">
<head>
   <!-- meta data -->
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Syntway</title>

   <!-- favicon -->
   <link rel="shortcut icon" href="assets/img/logo.png" type="image/x-icon">
   <link rel="apple-touch-icon" href="assets/img/logo.png">

   <!-- node_module css file -->
   
   <!-- <link rel="stylesheet" href="./assets/node_modules/google.font/index.css"> -->
   <link rel="stylesheet" href="./assets/node_modules/bootstrap/dist/css/bootstrap.min.css">
   <link rel="stylesheet" href="./assets/node_modules/bootstrap-icons/font/bootstrap-icons.min.css">
   <link rel="stylesheet" href="./assets/node_modules/aos/dist/aos.css">
   <link rel="stylesheet" href="./assets/node_modules/@fortawesome/fontawesome-free/css/all.min.css">
   <link rel="stylesheet" href="./assets/node_modules/glightbox/dist/css/glightbox.min.css">
   <link rel="stylesheet" href="./assets/node_modules/swiper/swiper-bundle.min.css">

   <!-- custom css file -->
   <link rel="stylesheet" href="./assets/css/style.css">
   
</head>
<body>
   