// team function 
export default function team() {
   // do something
}
team(); 
// End team function 