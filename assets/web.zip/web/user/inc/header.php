<?php include '../form/dashboard.php'; // fetch data to database ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Syntway</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="../assets/img/logo.png" rel="icon">
  <link href="../assets/img/logo.png" rel="apple-touch-icon">

  <!-- Vendor CSS Files -->
  <link href="../assets/node_modules/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/node_modules/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/node_modules/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="../assets/node_modules/quill/quill.snow.css" rel="stylesheet">
  <link href="../assets/node_modules/quill/quill.bubble.css" rel="stylesheet">
  <link href="../assets/node_modules/remixicon/remixicon.css" rel="stylesheet">
  <link href="../assets/node_modules/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Syntway_Admin
  * Updated: March 09 2024 with Bootstrap v5.3.2
  * Template URL: https://github.com/synt-way/Syntway_Admin
  * Author: Syntway
  * License: https://syntway.org/license/
  ======================================================== -->
</head>

<body>