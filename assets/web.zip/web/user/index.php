<?php 
  include './inc/header.php'; // include header section 
  include './pages/navbar.php'; // navbar section 
  include './pages/sidebar.php'; // sidebar section 
  include './pages/dashboard.php';  // main section 
  include './pages/footer.php'; // footer section 
  include './inc/footer.php';  // include footer section 
?>