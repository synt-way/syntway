<?php
include '../form/db_connection.php'; // database connection 

session_start();
if (!isset($_SESSION['username'])) {
    header("Location: ../");
    exit();
}

$username = $_SESSION['username'];

// Retrieve user information
$sql = "SELECT * FROM users WHERE username='$username'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
              

    // Populate variables with user information
    $src = 'data:image/jpeg;base64,'. base64_encode($row['image_data']); 
    $fname = $row['fname']; 
    $lname = $row['lname']; 
    $fullname = $row['fname'] .' '. $row['lname']; 
    $username = $row['username']; 
    $about = $row['about'];
    $company = $row['company'];
    $job = $row['job'];
    $country = $row['country'];
    $address = $row['address'];
    $phone = $row['phone'];
    $twitter = $row['twitter'];
    $facebook = $row['facebook'];
    $instagram = $row['instagram'];
    $linkedin = $row['linkedin'];
    $password = $row['password']; 

$conn->close();
?>