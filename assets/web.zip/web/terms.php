<?php 
   include './inc/header.php'; // include header section 
   include './pages/navbar.php'; // navbar section 
   include './pages/terms.php'; // terms and conditions 
   include './pages/footer.php'; // footer section 
   include './inc/footer.php'; // include footer section 
?>

