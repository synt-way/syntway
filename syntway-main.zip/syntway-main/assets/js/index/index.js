// import './module' folder to all files
export * as spinner from './module/spinner.js';
export * as header from './module/header.js';
export * as footer from './module/footer.js';

//export * as independence from './module/independence.js';
